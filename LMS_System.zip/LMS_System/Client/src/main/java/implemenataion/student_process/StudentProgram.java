package implemenataion.student_process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import api.rpc.Course;
import api.rpc.CourseListRequest;
import api.rpc.CourseListResponse;
import api.rpc.CrudApplicationRequest;
import api.rpc.CrudApplicationServiceGrpc;
import api.rpc.GetCourseServiceGrpc;
import api.rpc.DeleteAccountRequest;
import api.rpc.FindAccountRequest;
import api.rpc.FindAccountResponse;
import api.rpc.FindPasswordRequest;
import api.rpc.FindPasswordResponse;
import api.rpc.LoginRequest;
import api.rpc.LoginResponse;
import api.rpc.LoginServiceGrpc;
import api.rpc.ResultResponse;
import api.rpc.Token;
import api.rpc.RegisterRequest;
import api.rpc.CrudStudentAccountServiceGrpc;
import api.rpc.UpdateAccountRequest;

public class StudentProgram {
	private Token token;
	private String name;
	private ManagedChannel channel;
	private CrudStudentAccountServiceGrpc.CrudStudentAccountServiceBlockingStub crudAccountStub;
	private GetCourseServiceGrpc.GetCourseServiceBlockingStub getCourseStub;
	private CrudApplicationServiceGrpc.CrudApplicationServiceBlockingStub crudApplicationStub;
	private LoginServiceGrpc.LoginServiceBlockingStub loginStub;
	
	public StudentProgram() {
		channel = ManagedChannelBuilder.forAddress("localhost", 9090).usePlaintext().build();
		crudAccountStub = CrudStudentAccountServiceGrpc.newBlockingStub(channel);
		getCourseStub = GetCourseServiceGrpc.newBlockingStub(channel);
		crudApplicationStub = CrudApplicationServiceGrpc.newBlockingStub(channel);
		loginStub = LoginServiceGrpc.newBlockingStub(channel);
	}
	public static void main(String[] args) {
		BufferedReader objectReader = new BufferedReader(new InputStreamReader(System.in));
		StudentProgram main = new StudentProgram();
		main.firstMenu(objectReader);
	}
	private void firstMenu(BufferedReader objectReader) {
		try {
			while (true) {
				printFirstMenu();
				String choiceMenu = objectReader.readLine().trim();
				switch (choiceMenu) {
				case "1":
					loginInput(objectReader);
					break;
				case "2":
					registerInput(objectReader);
					break;
				case "3":
					findAccountInput(objectReader);
					break;
				case "4":
					findPasswordInput(objectReader);
					break;
				case "5":
					break;
				case "X":
					System.exit(0);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
			StudentProgram main = new StudentProgram();
			main.firstMenu(objectReader);
		}
	}
	private void printFirstMenu() {
		System.out.println("*********************MENU*********************");
		System.out.println("1: 로그인");
		System.out.println("2: 회원가입");
		System.out.println("3: 계정찾기");
		System.out.println("4: 비밀번호 찾기");
		System.out.println("X: 종료");
		System.out.print("입력: ");
	}
	
	public void loginInput(BufferedReader objectReader) throws IOException {
		System.out.println("*********************LOGIN*********************");
		while(true) {
			System.out.print("학생계정 ID: ");
			String id = objectReader.readLine().trim();
			System.out.print("학생계정 Password: ");
			String password = objectReader.readLine().trim();
			if(id.length() <= 10 && password.length() <= 10) {
				login(id, password, objectReader); break;
			} else System.out.println("10자 이내의 ID와 PASSWORD를 입력해주세요");
		}
	}
	private void login(String id, String password, BufferedReader objectReader) throws IOException{
			LoginRequest request = LoginRequest.newBuilder().setProcess("Student").setId(id).setPassword(password).build();
			LoginResponse response = loginStub.login(request);
			String result = response.getResult();
			if (result.equals("Success")) {
				token = response.getToken();
				name = response.getName();
				userMenu(objectReader);
			} 
			else if(result.equals("NullData")) loginFailOption(objectReader);
			else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요."); 
	}
	private void loginFailOption(BufferedReader objectReader) throws IOException {
		System.out.println("입력한 ID와 PASSWORD에 맞는 계정이 업습니다.");
		System.out.println("재시도 하시겠습니까?");
		System.out.println("1: 재시도");
		System.out.println("2: 로그인 종료");
		System.out.print("입력: ");
		String choice = objectReader.readLine().trim();
		switch (choice) {
		case "1":
			loginInput(objectReader);
			break;
		case "2":
			break;
		}
	}	
	public void registerInput(BufferedReader objectReader) throws IOException {
		System.out.println("*********************회원가입*********************");
		while(true) {
			System.out.println("영문 이름 입력 ");
			System.out.print("성: ");
			String firstName = objectReader.readLine().trim();
			System.out.print("이름: ");
			String lastName = objectReader.readLine().trim();
			System.out.print("학번: ");
			String studentId = readIntegerInput("학번: ", objectReader);
			System.out.print("ID: ");
			String id = objectReader.readLine().trim();
			System.out.print("Password: ");
			String password = objectReader.readLine().trim();
			if(id.length() <= 10 && password.length() <= 10) {
				register(firstName, lastName, studentId, id, password, objectReader); break;
			} else System.out.println("10자 이내의 ID와 PASSWORD를 입력해주세요");
		}
	}
	private void register(String firstName, String lastName, String studentId, String id, String password, BufferedReader objectReader) throws IOException {
		RegisterRequest request = RegisterRequest.newBuilder()
				.setFirstName(firstName)
				.setLastName(lastName)
				.setStudentId(Integer.parseInt(studentId))
				.setId(id)
				.setPassword(password).build();
		ResultResponse response = crudAccountStub.register(request);
		String result = response.getResult();
			
		if(result.equals("Success")) System.out.println("회원가입 됐습니다.");
		else if(result.equals("NullData")) System.out.println("학생이 존재하지 않습니다. 학교에 문의하여 먼저 등록하세요.");
		else if(result.equals("AlreadyExistAccount")) System.out.println("이미 등록된 회원입니다."); 
		else if(result.equals("AlreadyExistId")) System.out.println("이미 존재하는 아이디입니다.\n다른 아이디로 회원가입하세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private void findAccountInput(BufferedReader objectReader) throws IOException {
			System.out.println("*********************계정찾기*********************");
			System.out.println("영문 이름 입력 ");
			System.out.print("성: ");
			String firstName = objectReader.readLine().trim();
			System.out.print("이름: ");
			String lastName = objectReader.readLine().trim();
			System.out.print("학번: ");
			String studentId = readIntegerInput("학번: ", objectReader);
			findAccount(firstName, lastName, Integer.parseInt(studentId));
	}
	private void findAccount(String firstName, String lastName, int studentId) {
		FindAccountRequest request = FindAccountRequest.newBuilder().setFirstName(firstName).setLastName(lastName).setStudentId(studentId).build();
		FindAccountResponse response = crudAccountStub.findAccount(request);
		String result = response.getResult();
		if(result.equals("Success"))System.out.println(firstName + lastName + "님의 ID: " + response.getId());
	    else if(result.equals("NullData")) System.out.println("해당 학생정보의 계정이 존재하지 않습니다.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		
	}
	private void findPasswordInput(BufferedReader objectReader) throws IOException {
		System.out.println("*********************비밀번호 찾기*********************");
		System.out.println("영문 이름 입력 ");
		System.out.print("성: ");
		String firstName = objectReader.readLine().trim();
		System.out.print("이름: ");
		String lastName = objectReader.readLine().trim();
		System.out.print("학번: ");
		String studentId = readIntegerInput("학번: ", objectReader);
		System.out.print("ID: ");
		String id = objectReader.readLine().trim();
		findPassword(firstName, lastName, Integer.parseInt(studentId), id);
	}
	private void findPassword(String firstName, String lastName, int studentId, String id) {
		FindPasswordRequest request = FindPasswordRequest.newBuilder().setFirstName(firstName).setLastName(lastName).setStudentId(studentId).setId(id).build();
		FindPasswordResponse response = crudAccountStub.findPassword(request);
		String result = response.getResult();
		if(result.equals("Success"))System.out.println(firstName + lastName + "님의 PASSWORD: " + response.getPassword());
		else if(result.equals("NullData")) System.out.println("해당 학생정보의 계정이 존재하지 않습니다.");
		else  System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		
	}
	private void userMenu(BufferedReader objectReader) {
		try {
			System.out.println(name + "님 환영합니다.");
			out:while (true) {
				printUserMenu();
				String choiceMenu = objectReader.readLine().trim();
				switch (choiceMenu) {
				case "1":
					getAllCourse(); 
					break;
				case "2":
					printAttendedList();
					break;
				case "3":
					printApplicationList(); 
					break;
				case "4":
					updateApplicationList(objectReader);
					break;
				case "5":
					updateAccountInput(objectReader);
					break;
				case "6":
					deleteAccountInput(objectReader);
					break;
				case "X":
					break out;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void printUserMenu() {
		System.out.println("*********************MENU*********************");
		System.out.println("1: 모든강좌 출력");
		System.out.println("2: 이전 수강내역 출력");
		System.out.println("3: 수강신청 내역 출력");
		System.out.println("4: 수간신청 변경");
		System.out.println("5: ID/비밀번호 변경");
		System.out.println("6: 계정삭제");
		System.out.println("X: 종료");
		System.out.print("입력: ");
	}	
	private List<Course> getAllCourse() {
		CourseListRequest request = CourseListRequest.newBuilder().setToken(token).setProcess("Student").build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = response.getCourseList();
		String result = response.getResult();
		
		if(result.equals("Success")) printCourseList(list);
		else if(result.equals("NullData")) System.out.println("강좌가 존재하지 않습니다.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		return list;
	}
	private void printAttendedList() {
		CourseListRequest request = CourseListRequest.newBuilder().setToken(token).setProcess("Student").setIsAttendedList(true).build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = response.getCourseList();
		String result = response.getResult();
		
		if(result.equals("Success")) printCourseList(list);
		else if(result.equals("NullData")) System.out.println("이전 수강내역이 없습니다.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private List<Course> printApplicationList() {
		CourseListRequest request = CourseListRequest
				.newBuilder()
				.setToken(token)
				.setProcess("Student")
				.setIsApplicationList(true)
				.build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = response.getCourseList();
		String result = response.getResult();
		
		if(result.equals("Success")) printCourseList(list);
		else if(result.equals("NullData")) System.out.println("신청한 강좌가 존재하지 않습니다.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		return list;
	}
	private void updateApplicationList(BufferedReader objectReader) throws IOException {
		System.out.println("1: 강좌 선택하기");
		System.out.println("2: 신청내역 삭제하기");
		System.out.print("입력: ");
		String choice = objectReader.readLine().trim();
		switch(choice) {
		case"1":
			selectCourse(objectReader);
			break;
		case"2":
			deleteApplicationList(objectReader);
			break;
		case"X":
			break;
		default:
			System.out.println("잘못된 입력입니다.");
		}
	}
	private void selectCourse(BufferedReader objectReader) throws IOException {
		List<Course> list = getAllCourse();
		while (true) {
			System.out.println("신청할 강좌의 번호를 입력해주세요");
			System.out.print("입력: ");
			String sChoice = readIntegerInput("강좌번호: ", objectReader);
			int choice = Integer.parseInt(sChoice);
			if (choice <= list.size()) {
				Course choiceCourse = list.get(choice - 1);
				CrudApplicationRequest request = CrudApplicationRequest.newBuilder().setToken(token).setCourse(choiceCourse).build();
				ResultResponse response = crudApplicationStub.choiceNewCourse(request);
				String result = response.getResult();
				
				if(result.equals("Success")) System.out.println("성공적으로 신청했습니다.");
				else if(result.equals("AlreadyFullMaximumCredit")) System.out.println("신청 가능학점을 초과했습니다.");
				else if(result.equals("AlreadyExistInApplicationList")) System.out.println("동일한 강좌가 이미 신청됐습니다.");
				else if(result.equals("AlreadyFullMaximumStudent")) System.out.println("최대수강생을 초과합니다.");
				else if(result.equals("OverTwoReApplication")) System.out.println("한 학기에 2개를 초과하는 재수강을 금지합니다.");
				else if(result.equals("RequirementExist")) System.out.println("선수과목이 수행되지 않았습니다.");
				else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
				else  System.out.println("서버 오류입니다. 다시 시도해주세요.");
				break;
			} else System.out.println("정확한 번호를 입력해주세요");

		}
	}
	private void deleteApplicationList(BufferedReader objectReader) throws IOException {
		List<Course> list = printApplicationList();
		while(true) {
			if(list.size() == 0) break;
			else {
				System.out.println("삭제할 강좌의 번호를 입력해주세요");
				System.out.print("입력: ");
				String sChoice = readIntegerInput("강좌번호: ", objectReader);
				int choice = Integer.parseInt(sChoice);
				if (choice <= list.size()) {
					Course choiceCourse = list.get(choice - 1);
					CrudApplicationRequest request = CrudApplicationRequest.newBuilder().setToken(token).setCourse(choiceCourse).build();
					ResultResponse response = crudApplicationStub.deleteApplication(request);
					String result = response.getResult();
					
					if(result.equals("Success")) System.out.println("선택한 강좌를 삭제했습니다.");
					else if(result.equals("NullData")) System.out.println("강좌 삭제에 실패했습니다. 다시 시도해주세요.");
					else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
					else System.out.println("서버 오류입니다. 다시 시도해주세요.");
					break;
				} else System.out.println("정확한 번호를 입력해주세요");
			}
		}
	}
	private void updateAccountInput(BufferedReader objectReader) throws IOException {
		System.out.print("현재 ID: ");
		String usedId = objectReader.readLine().trim();
		System.out.print("현재 PASSWORD: ");
		String usedPassword = objectReader.readLine().trim();
		System.out.print("새로운 ID: ");
		String newId = objectReader.readLine().trim();
		System.out.print("새로운 PASSWORD: ");
		String newPassword = objectReader.readLine().trim();
		updateAccount(usedId, usedPassword, newId, newPassword);
	}
	private void updateAccount(String usedId, String usedPassword, String newId, String newPassword) {
		UpdateAccountRequest request = UpdateAccountRequest.newBuilder().setToken(token).setId(usedId).setPassword(usedPassword).setNewId(newId).setNewPassword(newPassword).build();
		ResultResponse response = crudAccountStub.updateAccount(request);
		String result = response.getResult();
		
		if(result.equals("Success")) {
			System.out.println("새로운 ID: " + newId );
			System.out.println("새로운 PASSWORD: " + newPassword );	
		}
		else if(result.equals("AlreadyExistId")) System.out.println("이미 존재하는 ID입니다. 다른 ID를 사용해주세요.");
		else if(result.equals("NullData")) System.out.println("입력하신 기존 ID와 PASSWORD가 옳지 않습니다.");
		else if(result.equals("NoneMatchInputIdPassword")) System.out.println("해당 계정의 ID와 PASSWORD를 입력해주세요.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private void deleteAccountInput(BufferedReader objectReader) throws IOException {
		System.out.print("성: ");
		String firstName = objectReader.readLine().trim();
		System.out.print("이름: ");
		String lastName = objectReader.readLine().trim();
		System.out.print("학번: ");
		String studentId = readIntegerInput("학번: ", objectReader);
		System.out.print("ID: ");
		String id = objectReader.readLine().trim();
		System.out.print("PASSWORD: ");
		String password = objectReader.readLine().trim();
		deleteAccount(firstName, lastName, studentId, id, password, objectReader); 
	}
	private void deleteAccount(String firstName, String lastName, String studentId, String id, String password, BufferedReader objectReader) {
		DeleteAccountRequest request =  DeleteAccountRequest.newBuilder().setToken(token).setFirstName(firstName).setLastName(lastName).setStudentId(Integer.parseInt(studentId)).setId(id).setPassword(password).build();
		ResultResponse response = crudAccountStub.deleteAccount(request);
		String result = response.getResult();
		if(result.equals("Success")) {System.out.println(firstName+lastName+ "님의 계정을 삭제했습니다."); firstMenu(objectReader);}
		else if(result.equals("NoneMatchStudentInfo")) System.out.println("해당 계정에 맞는 정보를 입력하세요. ");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}

	private void printCourseList(List<Course> list) {
		if(list.size() == 0) System.out.println("강좌가 존재하지 않습니다.");
		else {
			String sList = "";
			for (int i = 0; i < list.size(); i++) {
				Course course = list.get(i);
				sList += i+1 + "번 강좌 -->> " +
						"강좌명: " + course.getName() + ", 강좌ID: " + course.getCourseId() + 
						", REQUIREMENT1: " + course.getRequirement1() + ", REQUIREMENT2: " + course.getRequirement2() + 
						", 학점: " + course.getCredit() + ", 교수이름: " + course.getProfessorName() + 
						", 교수ID: " + course.getProfessorId() + ", 최대수강자수: " + course.getMaximumStudent() + 
						", 신청 학생수: " + course.getNumberOfStudent() +  "\n";
			} 
			System.out.println(sList);
		}
	}
	public String readIntegerInput(String message, BufferedReader objectReader) throws IOException {
		while(true) {
			String input = objectReader.readLine().trim();
	        try {
	            Integer.parseInt(input);
	            return input; // 변환 성공
	        } catch (NumberFormatException e) {
	        	System.out.println("숫자를 입력하세요.");
	        	System.out.print(message);
	        }
		}
	}
}