package api.rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ServiceForClient.proto")
public final class CrudStudentServiceGrpc {

  private CrudStudentServiceGrpc() {}

  public static final String SERVICE_NAME = "api.rpc.CrudStudentService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<api.rpc.CreateStudentRequest,
      api.rpc.ResultResponse> getCreateStudentMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateStudent",
      requestType = api.rpc.CreateStudentRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.CreateStudentRequest,
      api.rpc.ResultResponse> getCreateStudentMethod() {
    io.grpc.MethodDescriptor<api.rpc.CreateStudentRequest, api.rpc.ResultResponse> getCreateStudentMethod;
    if ((getCreateStudentMethod = CrudStudentServiceGrpc.getCreateStudentMethod) == null) {
      synchronized (CrudStudentServiceGrpc.class) {
        if ((getCreateStudentMethod = CrudStudentServiceGrpc.getCreateStudentMethod) == null) {
          CrudStudentServiceGrpc.getCreateStudentMethod = getCreateStudentMethod = 
              io.grpc.MethodDescriptor.<api.rpc.CreateStudentRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentService", "CreateStudent"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.CreateStudentRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentServiceMethodDescriptorSupplier("CreateStudent"))
                  .build();
          }
        }
     }
     return getCreateStudentMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.DeleteStudentRequest,
      api.rpc.ResultResponse> getDeleteStudentMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteStudent",
      requestType = api.rpc.DeleteStudentRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.DeleteStudentRequest,
      api.rpc.ResultResponse> getDeleteStudentMethod() {
    io.grpc.MethodDescriptor<api.rpc.DeleteStudentRequest, api.rpc.ResultResponse> getDeleteStudentMethod;
    if ((getDeleteStudentMethod = CrudStudentServiceGrpc.getDeleteStudentMethod) == null) {
      synchronized (CrudStudentServiceGrpc.class) {
        if ((getDeleteStudentMethod = CrudStudentServiceGrpc.getDeleteStudentMethod) == null) {
          CrudStudentServiceGrpc.getDeleteStudentMethod = getDeleteStudentMethod = 
              io.grpc.MethodDescriptor.<api.rpc.DeleteStudentRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentService", "DeleteStudent"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.DeleteStudentRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentServiceMethodDescriptorSupplier("DeleteStudent"))
                  .build();
          }
        }
     }
     return getDeleteStudentMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.UpdateStudentRequest,
      api.rpc.ResultResponse> getUpdateStudentMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateStudent",
      requestType = api.rpc.UpdateStudentRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.UpdateStudentRequest,
      api.rpc.ResultResponse> getUpdateStudentMethod() {
    io.grpc.MethodDescriptor<api.rpc.UpdateStudentRequest, api.rpc.ResultResponse> getUpdateStudentMethod;
    if ((getUpdateStudentMethod = CrudStudentServiceGrpc.getUpdateStudentMethod) == null) {
      synchronized (CrudStudentServiceGrpc.class) {
        if ((getUpdateStudentMethod = CrudStudentServiceGrpc.getUpdateStudentMethod) == null) {
          CrudStudentServiceGrpc.getUpdateStudentMethod = getUpdateStudentMethod = 
              io.grpc.MethodDescriptor.<api.rpc.UpdateStudentRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentService", "UpdateStudent"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.UpdateStudentRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentServiceMethodDescriptorSupplier("UpdateStudent"))
                  .build();
          }
        }
     }
     return getUpdateStudentMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CrudStudentServiceStub newStub(io.grpc.Channel channel) {
    return new CrudStudentServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CrudStudentServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new CrudStudentServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CrudStudentServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new CrudStudentServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class CrudStudentServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void createStudent(api.rpc.CreateStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateStudentMethod(), responseObserver);
    }

    /**
     */
    public void deleteStudent(api.rpc.DeleteStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteStudentMethod(), responseObserver);
    }

    /**
     */
    public void updateStudent(api.rpc.UpdateStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateStudentMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateStudentMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.CreateStudentRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_CREATE_STUDENT)))
          .addMethod(
            getDeleteStudentMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.DeleteStudentRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_DELETE_STUDENT)))
          .addMethod(
            getUpdateStudentMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.UpdateStudentRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_UPDATE_STUDENT)))
          .build();
    }
  }

  /**
   */
  public static final class CrudStudentServiceStub extends io.grpc.stub.AbstractStub<CrudStudentServiceStub> {
    private CrudStudentServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentServiceStub(channel, callOptions);
    }

    /**
     */
    public void createStudent(api.rpc.CreateStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreateStudentMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteStudent(api.rpc.DeleteStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteStudentMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateStudent(api.rpc.UpdateStudentRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateStudentMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class CrudStudentServiceBlockingStub extends io.grpc.stub.AbstractStub<CrudStudentServiceBlockingStub> {
    private CrudStudentServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public api.rpc.ResultResponse createStudent(api.rpc.CreateStudentRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreateStudentMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse deleteStudent(api.rpc.DeleteStudentRequest request) {
      return blockingUnaryCall(
          getChannel(), getDeleteStudentMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse updateStudent(api.rpc.UpdateStudentRequest request) {
      return blockingUnaryCall(
          getChannel(), getUpdateStudentMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class CrudStudentServiceFutureStub extends io.grpc.stub.AbstractStub<CrudStudentServiceFutureStub> {
    private CrudStudentServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> createStudent(
        api.rpc.CreateStudentRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreateStudentMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> deleteStudent(
        api.rpc.DeleteStudentRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteStudentMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> updateStudent(
        api.rpc.UpdateStudentRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateStudentMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_STUDENT = 0;
  private static final int METHODID_DELETE_STUDENT = 1;
  private static final int METHODID_UPDATE_STUDENT = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final CrudStudentServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(CrudStudentServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_STUDENT:
          serviceImpl.createStudent((api.rpc.CreateStudentRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_DELETE_STUDENT:
          serviceImpl.deleteStudent((api.rpc.DeleteStudentRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_UPDATE_STUDENT:
          serviceImpl.updateStudent((api.rpc.UpdateStudentRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class CrudStudentServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CrudStudentServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return api.rpc.ServiceForClient.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CrudStudentService");
    }
  }

  private static final class CrudStudentServiceFileDescriptorSupplier
      extends CrudStudentServiceBaseDescriptorSupplier {
    CrudStudentServiceFileDescriptorSupplier() {}
  }

  private static final class CrudStudentServiceMethodDescriptorSupplier
      extends CrudStudentServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    CrudStudentServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CrudStudentServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CrudStudentServiceFileDescriptorSupplier())
              .addMethod(getCreateStudentMethod())
              .addMethod(getDeleteStudentMethod())
              .addMethod(getUpdateStudentMethod())
              .build();
        }
      }
    }
    return result;
  }
}
