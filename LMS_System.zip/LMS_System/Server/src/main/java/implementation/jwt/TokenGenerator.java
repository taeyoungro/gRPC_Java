package implementation.jwt;

import java.util.Date;
import java.util.HashMap;

import api.rpc.Admin;
import api.rpc.Professor;
import api.rpc.Student;
import api.rpc.Token;
import implementation.exception.TokenException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.security.Keys;
import java.security.Key;

public class TokenGenerator {
	private static final Key SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);
	private static HashMap<String, Object> headerMap = new HashMap<String, Object>();
	private static HashMap<Token, Student> studentAndToken = new HashMap<>();
	private static HashMap<Token, Admin> adminAndToken = new HashMap<>();
	private static HashMap<Token, Professor> professorAndToken = new HashMap<>();
	
	public Token generateToken(Object object) {
		if(object instanceof Student) {
			Student student = (Student) object;
			String tokenValue = generateTokenValue(student.getStudentId());
			Token token = Token.newBuilder().setTokenValue(tokenValue).build();
			studentAndToken.put(token, student); 
			return token;
		} else if (object instanceof Professor) {
			Professor professor = (Professor) object;
			String tokenValue = generateTokenValue(professor.getProfessorId());
			Token token = Token.newBuilder().setTokenValue(tokenValue).build();
			professorAndToken.put(token, professor); 
			return token;
		} else if (object instanceof Admin) {
			Admin admin = (Admin) object;
			String tokenValue = generateTokenValue(admin.getId().hashCode());
			Token token = Token.newBuilder().setTokenValue(tokenValue).build();
			adminAndToken.put(token, admin); 
			return token;
		} else return null;
	}
	private String generateTokenValue(Integer userId) {
		Date now = new Date();
		Date expiration = new Date(now.getTime() + 3600000);
        headerMap.put("typ","JWT");
        headerMap.put("alg","HS256");
        return Jwts.builder().setHeader(headerMap).setIssuer(userId.toString())
				.setIssuedAt(now) .setExpiration(expiration) 
				.signWith(SECRET_KEY).compact();
	}
	public boolean validateToken(Token token, String process) throws TokenException {
        try {
    		Date now = new Date();
            Jws<Claims> claims = Jwts.parserBuilder().setSigningKey(SECRET_KEY)
                    .build() .parseClaimsJws(token.getTokenValue());
            if(process.equals("Student")) {
            	if (studentAndToken.containsKey(token) && 3600000 > now.getTime() - claims.getBody().getIssuedAt().getTime()) return true;
            	else throw new TokenException("TokenError");
            }
            else if(process.equals("Professor")) {
            	if (professorAndToken.containsKey(token) && 3600000 > now.getTime() - claims.getBody().getIssuedAt().getTime()) return true;
            	else throw new TokenException("TokenError");
            }
            else if (process.equals("Admin")){
            	if(adminAndToken.containsKey(token) && 3600000 > now.getTime() - claims.getBody().getIssuedAt().getTime()) return true;
            	else throw new TokenException("TokenError");
            } 
            else throw new TokenException("TokenError");
        } catch (Exception e) {
            e.printStackTrace();
            throw new TokenException("TokenError");
        }
    }
	public Student getStudent(Token token) throws TokenException {
		if(validateToken(token, "Student")) return studentAndToken.get(token);
		else throw new TokenException("TokenError");
	}
	public Professor getProfessor(Token token) throws TokenException {
		if(validateToken(token, "Professor")) return professorAndToken.get(token);
		else throw new TokenException("TokenError");
	}
}
