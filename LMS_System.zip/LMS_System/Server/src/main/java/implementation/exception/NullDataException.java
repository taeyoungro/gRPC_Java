package implementation.exception;

public class NullDataException extends Exception{
	private static final long serialVersionUID = 1L;
	public NullDataException(String errorMessage) {
		super(errorMessage);
	}
}
