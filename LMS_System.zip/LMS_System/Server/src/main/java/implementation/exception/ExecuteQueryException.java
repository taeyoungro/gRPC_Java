package implementation.exception;

public class ExecuteQueryException extends Exception{
	private static final long serialVersionUID = 1L;

	public ExecuteQueryException(String errorMessage) {
		super(errorMessage);
	}
}
