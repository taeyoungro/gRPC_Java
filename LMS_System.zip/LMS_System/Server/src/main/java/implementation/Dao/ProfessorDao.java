package implementation.Dao;

import api.rpc.Professor;
import implementation.constant.Constant;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;

public class ProfessorDao extends Dao{
	private final String PROFESSORID_PrimaryKey = "SYS_C008449";
	private final String ACCOUNTID_PrimaryKey = "SYS_C008452";
	private Constant constant;
	public ProfessorDao() {
		super.connect();
		constant = new Constant();
	}
	public boolean createProfessor(Professor professor) throws ServerErrorException, NullDataException, ExecuteQueryException {
		try {
			String createProfessorQuery = constant.getCreateProfessorQuery(professor);
			String createProfessorAccountQuery = constant.getCreateProfessorAccountQuery(professor);
			if(super.create(createProfessorQuery) && super.create(createProfessorAccountQuery)) return true; 
			else return false;
		} catch(ExecuteQueryException sqlError) {
			if(sqlError.getMessage().contains(PROFESSORID_PrimaryKey)) {
				throw new ServerErrorException("AlreadtExistSameProfessorId");
			}
			else if(sqlError.getMessage().contains(ACCOUNTID_PrimaryKey) || sqlError.getMessage().contains("PROFESSORID2_FK")) {
				super.delete(constant.getDeleteProfessorQuery(professor));
				throw new ServerErrorException("AlreadtExistSameId");
			}
			else throw new ServerErrorException("ServerError");
		}

	}
}
