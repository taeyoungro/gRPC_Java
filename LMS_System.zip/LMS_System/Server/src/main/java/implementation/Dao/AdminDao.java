package implementation.Dao;

import api.rpc.Admin;
import implementation.constant.Constant;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;

public class AdminDao extends Dao{
	private Constant constant;
	public AdminDao() {
		super.connect();
		constant = new Constant();
	}
	public boolean createAdmin(Admin admin) throws ServerErrorException, NullDataException, ExecuteQueryException {
		String createAdminQuery = constant.getCreateAdminQuery(admin);
		if(super.create(createAdminQuery)) return true; 
		else throw new ServerErrorException("ServerError");
	}

}
