package implementation.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import api.rpc.Student;
import implementation.constant.Constant;
import implementation.exception.ServerErrorException;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;

public class StudentDao extends Dao{
	private Constant constant;
	public StudentDao() {
		super.connect();
		constant = new Constant();
	}
	public List<Student> getStudentList(String condtion, String conditionValue) throws NullDataException, ExecuteQueryException, ServerErrorException {
		String studentListQuery = getStudentListQuery(condtion, conditionValue);
		ResultSet studentResultSet = super.retrieve(studentListQuery);
		if(studentResultSet == null) throw new NullDataException("NullData"); 
		else return addStudentInList(studentResultSet); 
	}
	private List<Student> addStudentInList(ResultSet resultSet) throws NullDataException {
		try {
			List<Student> studentList = new ArrayList<Student>();
			while (true) {
				Student student = Student.newBuilder()
					.setFirstName(resultSet.getNString("FIRSTNAME"))
					.setLastName(resultSet.getNString("LASTNAME"))
					.setStudentId(resultSet.getInt("STUDENTID"))
					.setDepartment(resultSet.getNString("DEPARTMENT"))
					.setMaximumCredit(resultSet.getInt("MAXIMUMCREDIT"))
					.setScore(resultSet.getDouble("SCORE"))	
					.setGender(resultSet.getString("GENDER")).build();
				studentList.add(student);
				if(!resultSet.next()) break;
			} return studentList;
		} catch (SQLException sqlError) {
			throw new NullDataException("NullData");
		}
	}
	public String getStudentListQuery(String condition, String conditionValue) {
		if(condition.equals("FIRSTNAME")) return constant.getStudentListQuery("WHERE FIRSTNAME = ", "'"+conditionValue +"'");
		else if(condition.equals("DEPARTMENT")) return constant.getStudentListQuery("WHERE DEPARTMENT = ", "'"+conditionValue +"'");
		else if(condition.equals("SCORE")) return constant.getStudentListQuery("WHERE SCORE < ", conditionValue + " AND SCORE >= " + (Integer.parseInt(conditionValue)-1));
		else if(condition.equals("GENDER")) return constant.getStudentListQuery("WHERE GENDER = ", "'"+conditionValue +"'");
		else if(condition.equals("APPLICATION")) return constant.getStudentListQuery("INNER JOIN application_list ON STUDENT.STUDENTID = application_list.STUDENTID WHERE COURSEID = ", conditionValue );
		else return constant.getStudentListQuery("", "");
	}
	public boolean createStudent(Student student) throws NullDataException, ExecuteQueryException {
	String createStudentQuery = constant.getCreateStudentQuery(student);
	return super.create(createStudentQuery);
	}
	public boolean deleteStudent(Student student) throws NullDataException, ExecuteQueryException {
		String deleteStudentAccount = constant.getDeleteAccountQueryForIntegrity(student);
		String deleteApplicationList = constant.getDeleteApplicationListQueryForIntegrity(student);
		String deleteAttendedList = constant.getDeleteAttendedListQueryForIntegrity(student);
		String deleteStudent = constant.getDeleteStudentQuery(student);
		super.delete(deleteStudentAccount);
		super.delete(deleteApplicationList);
		super.delete(deleteAttendedList);
		if(super.delete(deleteStudent) == 0)  throw new NullDataException("NullData");
		else return true;
	}
	public boolean updateStudent(Student originStudent, Student newStudent) throws ExecuteQueryException, NullDataException {
		String updateStudentQuery = constant.getUpdateStudentQuery(originStudent, newStudent);
		return super.update(updateStudentQuery);
	}
}
