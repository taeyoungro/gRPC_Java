package implementation.server;

import java.io.IOException;

import implementation.impl.*;
import io.grpc.Server;
import io.grpc.ServerBuilder;

public class SMain {
	public static void main(String[] args) throws IOException, InterruptedException {
		Server server = ServerBuilder.forPort(9090)
				.addService(new LoginForAllProcess())
				.addService(new GetCourseForAllProcess())
				.addService(new CrudStudentAccount())
				.addService(new CrudCourse())
				.addService(new GetStudentForProfessorAndAdmin())
				.addService(new CrudApplicationList())
				.addService(new CrudStudent())
				.addService(new CreateProfessor())
				.addService(new CreateAdmin())
				.build();
		server.start();	
		
		System.out.println(server.getPort() + "에서 서버 실행 !!!");
		System.out.println("Server Is Running !!!");
		server.awaitTermination();
	}
}
