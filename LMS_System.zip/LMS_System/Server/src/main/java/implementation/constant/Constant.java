package implementation.constant;

import api.rpc.Admin;
import api.rpc.Course;
import api.rpc.Professor;
import api.rpc.Student;

public class Constant {
	public String getStudentLoginQuery(String id, String password) {
		return "SELECT * FROM STUDENT_ACCOUNT INNER JOIN STUDENT ON STUDENT_ACCOUNT.STUDENTID = STUDENT.STUDENTID WHERE ID = '"
				+ id + "' AND PASSWORD = '" + password+ "'";
	}
	public String getAttendedCourseQuery(String id, String password) {
		return "SELECT PREVIOUSCOURSE.COURSEID, NAME, CREDIT, REQUIREMENT1, REQUIREMENT2, PROFESSOR.PROFESSORID, PROFESSOR.FIRSTNAME, PROFESSOR.LASTNAME FROM PREVIOUSCOURSE INNER JOIN PROFESSOR ON PREVIOUSCOURSE.PROFESSORID = PROFESSOR.PROFESSORID INNER JOIN ATTENDEDCOURSE_LIST ON PREVIOUSCOURSE.COURSEID = ATTENDEDCOURSE_LIST.COURSEID INNER JOIN STUDENT ON STUDENT.STUDENTID = ATTENDEDCOURSE_LIST.STUDENTID INNER JOIN STUDENT_ACCOUNT  ON STUDENT.STUDENTID = STUDENT_ACCOUNT.STUDENTID WHERE ID = '"
				+ id +"' AND PASSWORD = '" + password + "'";
	}

	public String getProfessorLoginQuery(String id, String password) {
		return "SELECT * FROM PROFESSOR INNER JOIN PROFESSOR_ACCOUNT ON PROFESSOR.PROFESSORID = PROFESSOR_ACCOUNT.PROFESSORID WHERE ID = '" 
				+ id + "' AND PASSWORD = '" + password + "'";
	}
	public String getAdminLoginQuery(String id, String password) {
		return "SELECT * FROM ADMIN_ACCOUNT WHERE ID = '" +id + "' AND PASSWORD = '" + password + "'";
	}
	
	public String getApplicationListQuery(int studnetId) {
		return "SELECT P.COURSEID, NAME, REQUIREMENT1, REQUIREMENT2, CREDIT, FIRSTNAME, LASTNAME, MAXIMUMSTUDENT, PROFESSOR.PROFESSORID, PC.NUMBEROFSTUDENT "
				+ "FROM ( SELECT STUDENTID, COURSEID FROM APPLICATION_LIST WHERE APPLICATION_LIST.STUDENTID = " 
				+ studnetId + ") P JOIN ( SELECT COURSEID, COUNT(*) AS NUMBEROFSTUDENT FROM APPLICATION_LIST GROUP BY COURSEID) PC ON P.COURSEID = PC.COURSEID "
				+ "INNER JOIN COURSE ON P.COURSEID = COURSE.COURSEID INNER JOIN PROFESSOR ON COURSE.PROFESSORID = PROFESSOR.PROFESSORID";
	}
	public String getCourseListQuery(String condition, String conditionValue, String having) {
		return "SELECT NAME, REQUIREMENT1, REQUIREMENT2, CREDIT, PROFESSOR.PROFESSORID, COURSE.COURSEID," +
				"FIRSTNAME, LASTNAME, MAXIMUMSTUDENT, COUNT(DISTINCT STUDENTID) AS NUMBEROFSTUDENT FROM COURSE " +
				"LEFT JOIN PROFESSOR ON COURSE.PROFESSORID = PROFESSOR.PROFESSORID " + 
				"LEFT JOIN APPLICATION_LIST ON COURSE.COURSEID = APPLICATION_LIST.COURSEID " + 
				condition + conditionValue + " " +
				"GROUP BY NAME, REQUIREMENT1, REQUIREMENT2, CREDIT, PROFESSOR.PROFESSORID, COURSE.COURSEID, FIRSTNAME, LASTNAME, MAXIMUMSTUDENT " +
				having;
	}
	public String getRegisterQuery(String firstName, String lastName, int studentId, String id, String password) {
		return "INSERT INTO STUDENT_ACCOUNT (STUDENTID, ID, PASSWORD) SELECT "
				+ studentId + ", '" 
				+ id +"', '" 
				+ password 
				+ "' FROM STUDENT STUDENT WHERE STUDENT.STUDENTID = "
				+ studentId + " AND STUDENT.FIRSTNAME = '" 
				+ firstName + "' AND STUDENT.LASTNAME = '" 
				+ lastName + "'";
	}
	public String getStudentAccountQuery(String firstName, String lastName, int studentId) {
		return "SELECT * FROM STUDENT_ACCOUNT INNER JOIN STUDENT ON STUDENT.STUDENTID = STUDENT_ACCOUNT.STUDENTID WHERE FIRSTNAME = '"
	            + firstName + "' AND LASTNAME = '" + lastName + "' AND STUDENT.STUDENTID = " + studentId;
	}
	public String getStudentPasswordQuery(String id) {
		return " AND  ID = '" + id + "'";
	}
	public String getUpdateStudentAccountQuery(String usedId, String usedPassword, String newId, String newPassword) {
		return "UPDATE STUDENT_ACCOUNT SET ID = '"+ newId + "', PASSWORD = '" + newPassword + "' WHERE ID = '" 
        + usedId + "' AND PASSWORD = '" + usedPassword+ "'";
	}
	public String getDeleteAccountQuery(String firstName, String lastName, int studentId, String id, String password) {
		return "DELETE FROM STUDENT_ACCOUNT WHERE STUDENT_ACCOUNT.STUDENTID "
		+ "IN ( SELECT STUDENT_ACCOUNT.STUDENTID FROM STUDENT_ACCOUNT "
		+ "JOIN STUDENT ON STUDENT_ACCOUNT.STUDENTID = STUDENT.STUDENTID "
		+ "WHERE STUDENT.STUDENTID = " 
		+ studentId + " AND FIRSTNAME = '" + firstName + "' AND LASTNAME = '" + lastName + "' "
		+ "AND ID = '" + id + "' AND PASSWORD = '" + password + "')" ;
	}
	public String getCreateCourseQuery(Course course) {
		return "INSERT INTO Course VALUES ("
				+ course.getCourseId() + ", '" 
				+ course.getName() + "', " 
				+ course.getRequirement1() + ", "
				+ course.getRequirement2() + ", "
				+ course.getCredit() + ", "
				+ course.getProfessorId() + ", "
				+ course.getMaximumStudent() + ")" ;
	}
	public String getCreateStudentQuery(Student student) {
		return "INSERT INTO STUDENT VALUES ("
				+ student.getStudentId() + ", '" 
				+ student.getFirstName() + "', '" 
				+ student.getLastName() + "', '"
				+ student.getDepartment() + "', "
				+ student.getMaximumCredit() + ", null, '"
				+ student.getGender() + "')" ;
	}
	public String getStudentListQuery(String condtion, String conditionValue) {
		return "SELECT * FROM STUDENT " + condtion + conditionValue;
	}
	public String getInsertCourseInApplicationQuery(int studentId, int courseId) {
		return "INSERT INTO APPLICATION_LIST VALUES (" + studentId + ", " + courseId + ", NULL)";
	}
	public String getDeleteCourseInApplicationQuery(int studentId, int courseId) {
		return "DELETE FROM APPLICATION_LIST WHERE STUDENTID = " + studentId + "AND COURSEID = " + courseId;
	}
	public String getDeleteAccountQueryForIntegrity(Student student) {
		return "DELETE FROM STUDENT_ACCOUNT WHERE STUDENTID = " + student.getStudentId();
	}
	public String getDeleteApplicationListQueryForIntegrity(Student student) {
		return "DELETE FROM APPLICATION_LIST WHERE STUDENTID = " + student.getStudentId();
	}
	public String getDeleteStudentQuery(Student student) {
		return "DELETE FROM STUDENT WHERE STUDENTID = " + student.getStudentId();
	}
	public String getDeleteAttendedListQueryForIntegrity(Student student) {
		return "DELETE FROM ATTENDEDCOURSE_LIST WHERE STUDENTID = " + student.getStudentId();
	}
	public String getUpdateStudentQuery(Student originStudent, Student newStudent) {
		return "UPDATE STUDENT SET FIRSTNAME = '" + newStudent.getFirstName() 
		        + "', LASTNAME = '" + newStudent.getLastName() 
		        + "', DEPARTMENT = '" + newStudent.getDepartment() 
		        + "', GENDER = '" + newStudent.getGender() + "' "  
		        + "WHERE STUDENTID = " + originStudent.getStudentId();
	}
	public String getDeleteCourseInApplicationQuery(int courseId) {
		return "DELETE FROM APPLICATION_LIST WHERE COURSEID = " + courseId;
	}
	public String getDeleteCourse(int courseId) {
		return "DELETE FROM COURSE WHERE COURSEID = " + courseId;
	}
	public String getUpdateCourseQuery(Course originCourse, Course newCourse) {
		return "UPDATE COURSE SET NAME = '" + newCourse.getName()
		        + "', CREDIT = " + newCourse.getCredit() 
		        + ", MAXIMUMSTUDENT = " + newCourse.getMaximumStudent()
		        + ", REQUIREMENT1 = " + newCourse.getRequirement1()
		        + ", REQUIREMENT2 = " + newCourse.getRequirement2()
		        + " WHERE COURSEID = " + originCourse.getCourseId();
	}
	public String getCreateProfessorQuery(Professor professor) {
		return "INSERT INTO PROFESSOR VALUES ('"
				+ professor.getFirstName() + "', '" 
				+ professor.getLastName() + "', "
				+ professor.getProfessorId() + ", '"
				+ professor.getGender() + "')" ;
	}
	public String getCreateProfessorAccountQuery(Professor professor) {
		return "INSERT INTO PROFESSOR_ACCOUNT VALUES ('"
				+ professor.getId() + "', '"
				+ professor.getPassword() + "', "
				+ professor.getProfessorId() + ")" ;
	}
	public String getPreviousCourseListQuery() {
		return "SELECT NAME, REQUIREMENT1, REQUIREMENT2, CREDIT, PROFESSOR.PROFESSORID, PREVIOUSCOURSE.COURSEID," +
				"FIRSTNAME, LASTNAME, MAXIMUMSTUDENT, COUNT(DISTINCT STUDENTID) AS NUMBEROFSTUDENT FROM PREVIOUSCOURSE " +
				"LEFT JOIN PROFESSOR ON PREVIOUSCOURSE.PROFESSORID = PROFESSOR.PROFESSORID " + 
				"LEFT JOIN ATTENDEDCOURSE_LIST ON PREVIOUSCOURSE.COURSEID = ATTENDEDCOURSE_LIST.COURSEID " + 
				"GROUP BY NAME, REQUIREMENT1, REQUIREMENT2, CREDIT, PROFESSOR.PROFESSORID, PREVIOUSCOURSE.COURSEID, FIRSTNAME, LASTNAME, MAXIMUMSTUDENT";
	}
	public String getCreateAdminQuery(Admin admin) {
		return "INSERT INTO admin_account VALUES ('" 
				+ admin.getId() + "' , '"
				+ admin.getPassword() + "')";
	}

	public String getDeleteProfessorQuery(Professor professor) {
		return "DELETE PROFESSOR WHERE PROFESSORID = " 
				+ professor.getProfessorId();
	}
	public String getDeleteProfessorAccountQuery(Professor professor) {
		return "DELETE PROFESSOR_ACCOUNT WHERE PROFESSORID = " 
				+ professor.getProfessorId();
	}
}



















