package implementation.impl;

import api.rpc.CreateCourseRequest;
import api.rpc.CrudCourseServiceGrpc.CrudCourseServiceImplBase;
import api.rpc.DeleteCourseRequest;
import api.rpc.ResultResponse;
import api.rpc.UpdateCourseRequest;
import implementation.Dao.CourseDao;
import implementation.exception.TokenException;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class CrudCourse  extends CrudCourseServiceImplBase{
	private CourseDao courseDao;
	private TokenGenerator tokenGenerator;
	private final String COURSEID_PrimaryKey = "SYS_C008457";
	private final String COURSENAME_Unique = "SYS_C008458";
	public CrudCourse() {
		courseDao = new CourseDao();
		tokenGenerator = new TokenGenerator();
	}
	@Override
	public void creatCourse(CreateCourseRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.getProfessor(request.getToken());
			if(courseDao.createNewCourse(request.getCourse())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if (sqlError.getMessage().contains(COURSEID_PrimaryKey)) result = "AlreadyExistSameCourseId"; 
			else if (sqlError.getMessage().contains(COURSENAME_Unique)) result = "AlreadyExistSameCourseName"; 
			else result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void deleteCourse(DeleteCourseRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.getProfessor(request.getToken());
			if(courseDao.deleteCourse(request.getCourse().getCourseId())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void updateCourse(UpdateCourseRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.getProfessor(request.getToken());
			if(courseDao.updateCourse(request.getOriginCourse(), request.getNewCourse())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if (sqlError.getMessage().contains(COURSENAME_Unique)) result = "AlreadyExistSameCourseName"; 
			else result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}
