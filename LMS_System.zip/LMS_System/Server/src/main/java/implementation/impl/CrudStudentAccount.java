package implementation.impl;

import api.rpc.DeleteAccountRequest;
import api.rpc.FindAccountRequest;
import api.rpc.FindAccountResponse;
import api.rpc.FindPasswordRequest;
import api.rpc.FindPasswordResponse;
import api.rpc.ResultResponse;
import api.rpc.RegisterRequest;
import api.rpc.Student;
import api.rpc.CrudStudentAccountServiceGrpc.CrudStudentAccountServiceImplBase;
import api.rpc.UpdateAccountRequest;
import implementation.Dao.StudentAccountDao;
import implementation.exception.ServerErrorException;
import implementation.exception.TokenException;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class CrudStudentAccount extends CrudStudentAccountServiceImplBase {
	private TokenGenerator tokenGenerator;
	private StudentAccountDao studentAccountDao;
	private final String ACCOUNTID_PrimaryKey = "SYS_C008470";
	private final String STUDENTID_Unique = "STUDENTID_UK";
	public CrudStudentAccount() {
		try {
			tokenGenerator = new TokenGenerator();
			studentAccountDao = new StudentAccountDao();
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}
	@Override
	public void findAccount(FindAccountRequest request, StreamObserver<FindAccountResponse> responseObserver) {
		FindAccountResponse response = null;
		try {
			String id = studentAccountDao.findStudentAccount(request.getFirstName(), request.getLastName(), request.getStudentId());
			response = FindAccountResponse.newBuilder().setResult("Success").setId(id).build(); 
		} catch (NullDataException nullDataError) {
			response = FindAccountResponse.newBuilder().setResult(nullDataError.getMessage()).build(); 
		} catch (ExecuteQueryException sqlError) {
			response = FindAccountResponse.newBuilder().setResult("ServerError").build();
		} catch (ServerErrorException serverError) {
			response = FindAccountResponse.newBuilder().setResult(serverError.getMessage()).build();
		}finally {
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void findPassword(FindPasswordRequest request, StreamObserver<FindPasswordResponse> responseObserver) {
		FindPasswordResponse response = null;
		try {
			String password = studentAccountDao.findPassword(request.getFirstName(), request.getLastName()
					,request.getStudentId(), request.getId());
			response = FindPasswordResponse.newBuilder().setResult("Success").setPassword(password).build();
		} catch (NullDataException nullDataError) {
			response = FindPasswordResponse.newBuilder().setResult(nullDataError.getMessage()).build(); 
		} catch (ExecuteQueryException sqlError) {
			response = FindPasswordResponse.newBuilder().setResult("ServerError").build();
		} catch (ServerErrorException serverError) {
			response = FindPasswordResponse.newBuilder().setResult(serverError.getMessage()).build();
		}
		responseObserver.onNext(response);
		responseObserver.onCompleted();
	}	
	@Override
	public void register(RegisterRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			if(studentAccountDao.register(request.getFirstName(), request.getLastName(),request.getStudentId(), request.getId(), request.getPassword()))
				result = "Success";  //DONE!!!!!!!!
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if(sqlError.getMessage().contains(STUDENTID_Unique)) result = "AlreadyExistAccount"; 
			else if (sqlError.getMessage().contains(ACCOUNTID_PrimaryKey)) result = "AlreadyExistId"; 
			else result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void updateAccount(UpdateAccountRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			Student student = tokenGenerator.getStudent(request.getToken()); 
			checkIdPassword(request.getId(), request.getPassword(), student.getId(), student.getPassword()); //DONE!!!!!!!!
			if(studentAccountDao.updateAccount(request.getId(), request.getPassword(), request.getNewId(), request.getNewPassword())) {
				result = "Success";
			}
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if(sqlError.getMessage().contains(ACCOUNTID_PrimaryKey)) result = "AlreadyExistId"; //DONE!!!!!!!!
			else result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void deleteAccount(DeleteAccountRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			Student student = tokenGenerator.getStudent(request.getToken()); //DONE!!!!!!!!
			checkStudentInfo(student, request.getFirstName(), request.getLastName(), request.getStudentId(), request.getId(),request.getPassword());
			if(studentAccountDao.deleteAccount(request.getFirstName(), request.getLastName(), request.getStudentId(), request.getId(),request.getPassword())) 
				result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	private void checkIdPassword(String inputId, String inputPassword, String originId, String originPassword) throws NullDataException {
		if (originId.equals(inputId) && originPassword.equals(inputPassword)) {} 
		else throw new NullDataException("NoneMatchInputIdPassword"); //DONE!!!!!!!!
	}
	private void checkStudentInfo(Student student, String firstName, String lastName, int studentId, String id, String password) throws NullDataException {
		if(student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)
				&& student.getStudentId()==studentId && student.getId().equals(id) && student.getPassword().equals(password) ) {}
		else throw new NullDataException("NoneMatchStudentInfo");
	}
}


