package implementation.impl;

import api.rpc.ResultResponse;
import api.rpc.CreateAdminRequest;
import api.rpc.CrudAdminServiceGrpc.CrudAdminServiceImplBase;
import implementation.Dao.AdminDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import io.grpc.stub.StreamObserver;;

public class CreateAdmin extends CrudAdminServiceImplBase{
	private AdminDao adminDao;
	public CreateAdmin() {
		adminDao = new AdminDao();
	}
	@Override
	public void createAdmin(CreateAdminRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			if(adminDao.createAdmin(request.getAdmin())) result = "Success";
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} catch (ServerErrorException serverError) {
			result = serverError.getMessage();
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}



