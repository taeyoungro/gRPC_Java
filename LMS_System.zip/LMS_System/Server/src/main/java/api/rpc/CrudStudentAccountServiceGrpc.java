package api.rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ServiceForCNS.proto")
public final class CrudStudentAccountServiceGrpc {

  private CrudStudentAccountServiceGrpc() {}

  public static final String SERVICE_NAME = "api.rpc.CrudStudentAccountService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<api.rpc.RegisterRequest,
      api.rpc.ResultResponse> getRegisterMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Register",
      requestType = api.rpc.RegisterRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.RegisterRequest,
      api.rpc.ResultResponse> getRegisterMethod() {
    io.grpc.MethodDescriptor<api.rpc.RegisterRequest, api.rpc.ResultResponse> getRegisterMethod;
    if ((getRegisterMethod = CrudStudentAccountServiceGrpc.getRegisterMethod) == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        if ((getRegisterMethod = CrudStudentAccountServiceGrpc.getRegisterMethod) == null) {
          CrudStudentAccountServiceGrpc.getRegisterMethod = getRegisterMethod = 
              io.grpc.MethodDescriptor.<api.rpc.RegisterRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentAccountService", "Register"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.RegisterRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentAccountServiceMethodDescriptorSupplier("Register"))
                  .build();
          }
        }
     }
     return getRegisterMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.FindAccountRequest,
      api.rpc.FindAccountResponse> getFindAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FindAccount",
      requestType = api.rpc.FindAccountRequest.class,
      responseType = api.rpc.FindAccountResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.FindAccountRequest,
      api.rpc.FindAccountResponse> getFindAccountMethod() {
    io.grpc.MethodDescriptor<api.rpc.FindAccountRequest, api.rpc.FindAccountResponse> getFindAccountMethod;
    if ((getFindAccountMethod = CrudStudentAccountServiceGrpc.getFindAccountMethod) == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        if ((getFindAccountMethod = CrudStudentAccountServiceGrpc.getFindAccountMethod) == null) {
          CrudStudentAccountServiceGrpc.getFindAccountMethod = getFindAccountMethod = 
              io.grpc.MethodDescriptor.<api.rpc.FindAccountRequest, api.rpc.FindAccountResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentAccountService", "FindAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.FindAccountRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.FindAccountResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentAccountServiceMethodDescriptorSupplier("FindAccount"))
                  .build();
          }
        }
     }
     return getFindAccountMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.FindPasswordRequest,
      api.rpc.FindPasswordResponse> getFindPasswordMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FindPassword",
      requestType = api.rpc.FindPasswordRequest.class,
      responseType = api.rpc.FindPasswordResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.FindPasswordRequest,
      api.rpc.FindPasswordResponse> getFindPasswordMethod() {
    io.grpc.MethodDescriptor<api.rpc.FindPasswordRequest, api.rpc.FindPasswordResponse> getFindPasswordMethod;
    if ((getFindPasswordMethod = CrudStudentAccountServiceGrpc.getFindPasswordMethod) == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        if ((getFindPasswordMethod = CrudStudentAccountServiceGrpc.getFindPasswordMethod) == null) {
          CrudStudentAccountServiceGrpc.getFindPasswordMethod = getFindPasswordMethod = 
              io.grpc.MethodDescriptor.<api.rpc.FindPasswordRequest, api.rpc.FindPasswordResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentAccountService", "FindPassword"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.FindPasswordRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.FindPasswordResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentAccountServiceMethodDescriptorSupplier("FindPassword"))
                  .build();
          }
        }
     }
     return getFindPasswordMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.UpdateAccountRequest,
      api.rpc.ResultResponse> getUpdateAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateAccount",
      requestType = api.rpc.UpdateAccountRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.UpdateAccountRequest,
      api.rpc.ResultResponse> getUpdateAccountMethod() {
    io.grpc.MethodDescriptor<api.rpc.UpdateAccountRequest, api.rpc.ResultResponse> getUpdateAccountMethod;
    if ((getUpdateAccountMethod = CrudStudentAccountServiceGrpc.getUpdateAccountMethod) == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        if ((getUpdateAccountMethod = CrudStudentAccountServiceGrpc.getUpdateAccountMethod) == null) {
          CrudStudentAccountServiceGrpc.getUpdateAccountMethod = getUpdateAccountMethod = 
              io.grpc.MethodDescriptor.<api.rpc.UpdateAccountRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentAccountService", "UpdateAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.UpdateAccountRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentAccountServiceMethodDescriptorSupplier("UpdateAccount"))
                  .build();
          }
        }
     }
     return getUpdateAccountMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.DeleteAccountRequest,
      api.rpc.ResultResponse> getDeleteAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteAccount",
      requestType = api.rpc.DeleteAccountRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.DeleteAccountRequest,
      api.rpc.ResultResponse> getDeleteAccountMethod() {
    io.grpc.MethodDescriptor<api.rpc.DeleteAccountRequest, api.rpc.ResultResponse> getDeleteAccountMethod;
    if ((getDeleteAccountMethod = CrudStudentAccountServiceGrpc.getDeleteAccountMethod) == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        if ((getDeleteAccountMethod = CrudStudentAccountServiceGrpc.getDeleteAccountMethod) == null) {
          CrudStudentAccountServiceGrpc.getDeleteAccountMethod = getDeleteAccountMethod = 
              io.grpc.MethodDescriptor.<api.rpc.DeleteAccountRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudStudentAccountService", "DeleteAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.DeleteAccountRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudStudentAccountServiceMethodDescriptorSupplier("DeleteAccount"))
                  .build();
          }
        }
     }
     return getDeleteAccountMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CrudStudentAccountServiceStub newStub(io.grpc.Channel channel) {
    return new CrudStudentAccountServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CrudStudentAccountServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new CrudStudentAccountServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CrudStudentAccountServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new CrudStudentAccountServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class CrudStudentAccountServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void register(api.rpc.RegisterRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getRegisterMethod(), responseObserver);
    }

    /**
     */
    public void findAccount(api.rpc.FindAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.FindAccountResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getFindAccountMethod(), responseObserver);
    }

    /**
     */
    public void findPassword(api.rpc.FindPasswordRequest request,
        io.grpc.stub.StreamObserver<api.rpc.FindPasswordResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getFindPasswordMethod(), responseObserver);
    }

    /**
     */
    public void updateAccount(api.rpc.UpdateAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateAccountMethod(), responseObserver);
    }

    /**
     */
    public void deleteAccount(api.rpc.DeleteAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteAccountMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getRegisterMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.RegisterRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_REGISTER)))
          .addMethod(
            getFindAccountMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.FindAccountRequest,
                api.rpc.FindAccountResponse>(
                  this, METHODID_FIND_ACCOUNT)))
          .addMethod(
            getFindPasswordMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.FindPasswordRequest,
                api.rpc.FindPasswordResponse>(
                  this, METHODID_FIND_PASSWORD)))
          .addMethod(
            getUpdateAccountMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.UpdateAccountRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_UPDATE_ACCOUNT)))
          .addMethod(
            getDeleteAccountMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.DeleteAccountRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_DELETE_ACCOUNT)))
          .build();
    }
  }

  /**
   */
  public static final class CrudStudentAccountServiceStub extends io.grpc.stub.AbstractStub<CrudStudentAccountServiceStub> {
    private CrudStudentAccountServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentAccountServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentAccountServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentAccountServiceStub(channel, callOptions);
    }

    /**
     */
    public void register(api.rpc.RegisterRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRegisterMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void findAccount(api.rpc.FindAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.FindAccountResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getFindAccountMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void findPassword(api.rpc.FindPasswordRequest request,
        io.grpc.stub.StreamObserver<api.rpc.FindPasswordResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getFindPasswordMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateAccount(api.rpc.UpdateAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateAccountMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteAccount(api.rpc.DeleteAccountRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteAccountMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class CrudStudentAccountServiceBlockingStub extends io.grpc.stub.AbstractStub<CrudStudentAccountServiceBlockingStub> {
    private CrudStudentAccountServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentAccountServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentAccountServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentAccountServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public api.rpc.ResultResponse register(api.rpc.RegisterRequest request) {
      return blockingUnaryCall(
          getChannel(), getRegisterMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.FindAccountResponse findAccount(api.rpc.FindAccountRequest request) {
      return blockingUnaryCall(
          getChannel(), getFindAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.FindPasswordResponse findPassword(api.rpc.FindPasswordRequest request) {
      return blockingUnaryCall(
          getChannel(), getFindPasswordMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse updateAccount(api.rpc.UpdateAccountRequest request) {
      return blockingUnaryCall(
          getChannel(), getUpdateAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse deleteAccount(api.rpc.DeleteAccountRequest request) {
      return blockingUnaryCall(
          getChannel(), getDeleteAccountMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class CrudStudentAccountServiceFutureStub extends io.grpc.stub.AbstractStub<CrudStudentAccountServiceFutureStub> {
    private CrudStudentAccountServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudStudentAccountServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudStudentAccountServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudStudentAccountServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> register(
        api.rpc.RegisterRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getRegisterMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.FindAccountResponse> findAccount(
        api.rpc.FindAccountRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getFindAccountMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.FindPasswordResponse> findPassword(
        api.rpc.FindPasswordRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getFindPasswordMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> updateAccount(
        api.rpc.UpdateAccountRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateAccountMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> deleteAccount(
        api.rpc.DeleteAccountRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteAccountMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_REGISTER = 0;
  private static final int METHODID_FIND_ACCOUNT = 1;
  private static final int METHODID_FIND_PASSWORD = 2;
  private static final int METHODID_UPDATE_ACCOUNT = 3;
  private static final int METHODID_DELETE_ACCOUNT = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final CrudStudentAccountServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(CrudStudentAccountServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_REGISTER:
          serviceImpl.register((api.rpc.RegisterRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_FIND_ACCOUNT:
          serviceImpl.findAccount((api.rpc.FindAccountRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.FindAccountResponse>) responseObserver);
          break;
        case METHODID_FIND_PASSWORD:
          serviceImpl.findPassword((api.rpc.FindPasswordRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.FindPasswordResponse>) responseObserver);
          break;
        case METHODID_UPDATE_ACCOUNT:
          serviceImpl.updateAccount((api.rpc.UpdateAccountRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_DELETE_ACCOUNT:
          serviceImpl.deleteAccount((api.rpc.DeleteAccountRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class CrudStudentAccountServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CrudStudentAccountServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return api.rpc.ServiceForCNS.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CrudStudentAccountService");
    }
  }

  private static final class CrudStudentAccountServiceFileDescriptorSupplier
      extends CrudStudentAccountServiceBaseDescriptorSupplier {
    CrudStudentAccountServiceFileDescriptorSupplier() {}
  }

  private static final class CrudStudentAccountServiceMethodDescriptorSupplier
      extends CrudStudentAccountServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    CrudStudentAccountServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CrudStudentAccountServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CrudStudentAccountServiceFileDescriptorSupplier())
              .addMethod(getRegisterMethod())
              .addMethod(getFindAccountMethod())
              .addMethod(getFindPasswordMethod())
              .addMethod(getUpdateAccountMethod())
              .addMethod(getDeleteAccountMethod())
              .build();
        }
      }
    }
    return result;
  }
}
