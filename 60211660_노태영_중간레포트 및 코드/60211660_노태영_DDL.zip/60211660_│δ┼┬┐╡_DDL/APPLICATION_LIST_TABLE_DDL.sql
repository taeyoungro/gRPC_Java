--------------------------------------------------------
--  ������ ������ - ȭ����-10��-24-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table APPLICATION_LIST
--------------------------------------------------------

  CREATE TABLE "CNSUSER"."APPLICATION_LIST" 
   (	"STUDENTID" NUMBER(8,0), 
	"COURSEID" NUMBER(5,0), 
	"GRADE" VARCHAR2(2 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "CLIENTSERVERTABLESPACE" ;
--------------------------------------------------------
--  Constraints for Table APPLICATION_LIST
--------------------------------------------------------

  ALTER TABLE "CNSUSER"."APPLICATION_LIST" MODIFY ("STUDENTID" NOT NULL ENABLE);
  ALTER TABLE "CNSUSER"."APPLICATION_LIST" MODIFY ("COURSEID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table APPLICATION_LIST
--------------------------------------------------------

  ALTER TABLE "CNSUSER"."APPLICATION_LIST" ADD CONSTRAINT "STUDENTID_FK_LIST" FOREIGN KEY ("STUDENTID")
	  REFERENCES "CNSUSER"."STUDENT" ("STUDENTID") ENABLE;
  ALTER TABLE "CNSUSER"."APPLICATION_LIST" ADD CONSTRAINT "LISTCOURSEID_FK_LIST" FOREIGN KEY ("COURSEID")
	  REFERENCES "CNSUSER"."COURSE" ("COURSEID") ENABLE;
