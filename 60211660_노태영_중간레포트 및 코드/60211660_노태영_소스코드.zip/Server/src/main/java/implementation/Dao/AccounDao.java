package implementation.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import api.rpc.Admin;
import api.rpc.Course;
import api.rpc.Professor;
import api.rpc.Student;
import implementation.constant.Constant;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;

public class AccounDao extends Dao{
	private Constant constant;
	
	public AccounDao() {
		super.connect();
		constant = new Constant();
	}
	public Object login(String id, String password, String process) throws NullDataException, ServerErrorException, ExecuteQueryException {
		ResultSet loginobjectResultSet;
		ResultSet attendedCourseResultSet;
		String query;
		if(process.equals("Student")) {
			query = constant.getStudentLoginQuery(id, password);	
			loginobjectResultSet = super.retrieve(query);
			
			query = constant.getAttendedCourseQuery(id, password);
			attendedCourseResultSet = super.retrieve(query);
			return getStudent(loginobjectResultSet, attendedCourseResultSet);
		}
		else if(process.equals("Professor")) {	
			query = constant.getProfessorLoginQuery(id, password);
			loginobjectResultSet = super.retrieve(query);
			return getProfessor(loginobjectResultSet);
		} 
		else if(process.equals("Admin")) {
			query = constant.getAdminLoginQuery(id, password);
			loginobjectResultSet = super.retrieve(query);
			return getAdmin(loginobjectResultSet);
		}
		else throw new ServerErrorException("ServerError");
	}
	private Object getAdmin(ResultSet loginobjectResultSet) throws  NullDataException {
		 try {
			 return Admin.newBuilder()
				.setId(loginobjectResultSet.getString("ID"))
				.setPassword(loginobjectResultSet.getString("PASSWORD")).build();
		 } catch (SQLException sqlError) {
			 throw new NullDataException("NullData");
		 }	
	}
	private Object getProfessor(ResultSet loginobjectResultSet) throws  NullDataException {
		try {
			return Professor.newBuilder()
				.setFirstName(loginobjectResultSet.getNString("FIRSTNAME"))
				.setLastName(loginobjectResultSet.getNString("LASTNAME"))
				.setGender(loginobjectResultSet.getString("GENDER"))
				.setProfessorId(loginobjectResultSet.getInt("PROFESSORID")).build();
		} catch (SQLException sqlError) {
			throw new NullDataException("NullData");
		}	
	}
	private Object getStudent(ResultSet loginobjectResultSet, ResultSet attendedCourseResultSet) throws NullDataException{
		try {
			List<Course> attendedCourse = getAttendedCourseList(attendedCourseResultSet);
			return Student.newBuilder()
				.setId(loginobjectResultSet.getString("ID"))
					.setPassword(loginobjectResultSet.getString("PASSWORD"))
					.setStudentId(loginobjectResultSet.getInt("STUDENTID"))
					.setFirstName(loginobjectResultSet.getNString("FIRSTNAME"))
					.setLastName(loginobjectResultSet.getNString("LASTNAME"))
					.setDepartment(loginobjectResultSet.getNString("DEPARTMENT"))
					.setMaximumCredit(loginobjectResultSet.getInt("MAXIMUMCREDIT"))
					.setScore(loginobjectResultSet.getDouble("SCORE"))
					.setGender(loginobjectResultSet.getNString("GENDER")).addAllAttendedCourse(attendedCourse).build();
		} catch (SQLException sqlError) {
			throw new NullDataException("NullData");
		}	
	}
	private List<Course> getAttendedCourseList(ResultSet attendedCourseResultSet) throws NullDataException{
		try{
			ArrayList<Course> attendedCourse = new ArrayList<>();
			if (attendedCourseResultSet == null) return attendedCourse;	
			while(true) {
				attendedCourse.add(
					Course.newBuilder()
					.setCourseId(attendedCourseResultSet.getInt("COURSEID"))
					.setName(attendedCourseResultSet.getNString("NAME"))
					.setCredit(attendedCourseResultSet.getInt("CREDIT"))
					.setRequirement1(attendedCourseResultSet.getInt("REQUIREMENT1"))
					.setRequirement2(attendedCourseResultSet.getInt("REQUIREMENT2"))
					.setProfessorId(attendedCourseResultSet.getInt("PROFESSORID"))
					.setProfessorName(attendedCourseResultSet.getNString("FIRSTNAME") + attendedCourseResultSet.getNString("LASTNAME"))
					.build());
				if(!attendedCourseResultSet.next()) break;
			} return attendedCourse;
		} catch (SQLException sqlError) {
			return new ArrayList<Course>();
		}
	}
}