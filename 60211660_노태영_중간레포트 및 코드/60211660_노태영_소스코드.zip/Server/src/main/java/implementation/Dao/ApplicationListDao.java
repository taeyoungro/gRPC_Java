package implementation.Dao;

import implementation.constant.Constant;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;

public class ApplicationListDao extends Dao{
	Constant constant;
	public ApplicationListDao() {
		super.connect();
		constant = new Constant();
	}
	public String insertCourseInApplicationList(int studentId, int courseId) throws ExecuteQueryException, NullDataException {
		String insertCourseInApplicationQuery = constant.getInsertCourseInApplicationQuery(studentId, courseId);
		if(super.create(insertCourseInApplicationQuery)) return "Success";
		else throw new NullDataException("NullData");
	}
	public String deleteCourseInApplicationList(int studentId, int courseId) throws ExecuteQueryException, NullDataException {
		String deleteCourseInApplicationQuery = constant.getDeleteCourseInApplicationQuery(studentId, courseId);
		if(super.delete(deleteCourseInApplicationQuery) == 0)  throw new NullDataException("NullData");
		else return "Success";
	}
}
