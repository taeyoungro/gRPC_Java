package implementation.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import api.rpc.Course;
import implementation.constant.Constant;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;

public class CourseDao extends Dao{
	Constant constant;
	public CourseDao() {
		super.connect();
		constant = new Constant();
	}
	public List<Course> getApplicationList(int studnetId) throws   NullDataException, ExecuteQueryException, ServerErrorException {
		String query = constant.getApplicationListQuery(studnetId);
		ResultSet courseResultSet =  super.retrieve(query);
		return addCourseInList(courseResultSet);
	}
	public List<Course> getCourseList(String condtition, String conditionValue) throws ExecuteQueryException, ServerErrorException, NullDataException {
		String query;
		if(condtition.equals("CREDIT")) query = constant.getCourseListQuery("WHERE CREDIT = ", conditionValue, "");
		else if(condtition.equals("REQUIREMENT1") && conditionValue.equals("NotNull")) query = constant.getCourseListQuery("WHERE REQUIREMENT1 != ", "0", "");
		else if(condtition.equals("REQUIREMENT1") && conditionValue.equals("Null")) query = constant.getCourseListQuery("WHERE REQUIREMENT1 = ", "0", "");
		else if(condtition.equals("MYCOURSE")) query = constant.getCourseListQuery("WHERE PROFESSOR.PROFESSORID = ", conditionValue, "");
		else if(condtition.equals("OTHERCOURSE"))  query = constant.getCourseListQuery("WHERE PROFESSOR.PROFESSORID != ", conditionValue, "");
		else if(condtition.equals("NUMBEROFSTUDENT")) query = constant.getCourseListQuery("", "", "HAVING COUNT(DISTINCT STUDENTID) >= "+conditionValue+ " AND COUNT(DISTINCT STUDENTID) < " + (Integer.parseInt(conditionValue)+10));
		else if(condtition.equals("PREVIOUSCOURSE")) query = constant.getPreviousCourseListQuery();
		else query = constant.getCourseListQuery("", "", "");
		ResultSet courseResultSet =  super.retrieve(query);
		return addCourseInList(courseResultSet);
	}
	private List<Course> addCourseInList(ResultSet courseResultSet) throws NullDataException {
		try {
			List<Course> courseList = new ArrayList<Course>();
			while (true) {
				Course course = Course.newBuilder()
						.setCourseId(courseResultSet.getInt("COURSEID"))
						.setName(courseResultSet.getNString("NAME"))
						.setRequirement1(courseResultSet.getInt("REQUIREMENT1"))
						.setRequirement2(courseResultSet.getInt("REQUIREMENT2"))
						.setCredit(courseResultSet.getInt("CREDIT"))
						.setProfessorId(courseResultSet.getInt("PROFESSORID"))
						.setProfessorName(courseResultSet.getNString("FIRSTNAME") + courseResultSet.getNString("LASTNAME"))
						.setNumberOfStudent(courseResultSet.getInt("NUMBEROFSTUDENT"))
						.setMaximumStudent(courseResultSet.getInt("MAXIMUMSTUDENT"))
						.build();
				courseList.add(course);
				if(!courseResultSet.next()) return courseList;
			} 
		} catch (SQLException sqlError) {
			return new ArrayList<Course>();
		} 
	}
	public boolean createNewCourse(Course course) throws  NullDataException, ExecuteQueryException {
		String createCourseQuery = constant.getCreateCourseQuery(course);
		return super.create(createCourseQuery);
	}
	public boolean deleteCourse(int courseId) throws ExecuteQueryException, NullDataException {
		String deleteCourseInApplicaiton = constant.getDeleteCourseInApplicationQuery(courseId);
		String deleteCourse = constant.getDeleteCourse(courseId);
		super.delete(deleteCourseInApplicaiton);
		if(super.delete(deleteCourse) == 0)  throw new NullDataException("NullData");
		else return true;
	}
	public boolean updateCourse(Course originCourse, Course newCourse) throws ExecuteQueryException, NullDataException {
		String updateCourseQuery = constant.getUpdateCourseQuery(originCourse, newCourse);
		return super.update(updateCourseQuery);
	}
}
