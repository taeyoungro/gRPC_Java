package implementation.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import implementation.constant.Constant;
import implementation.exception.ServerErrorException;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;

public class StudentAccountDao extends Dao{
	Constant constant;
	
	public StudentAccountDao() {
		super.connect();
		constant = new Constant();
	}
	public String findStudentAccount(String firstName, String lastName, int studentId) throws NullDataException, ExecuteQueryException, ServerErrorException {
		String studentAccountQuery = constant.getStudentAccountQuery(firstName, lastName, studentId);
		ResultSet resultSet = super.retrieve(studentAccountQuery);
		return getResult(resultSet, "ID");
	}
	public String findPassword(String firstName, String lastName, int studentId, String id) throws NullDataException, ExecuteQueryException, ServerErrorException  {
		String studentPasswordQuery = constant.getStudentAccountQuery(firstName, lastName, studentId)                    
				+ constant.getStudentPasswordQuery(id); 
		ResultSet resultSet = super.retrieve(studentPasswordQuery);
		return getResult(resultSet, "PASSWORD");
	}
	public String getResult(ResultSet resultSet, String result) throws NullDataException {
		try {
			return resultSet.getString(result);
		}  catch (SQLException sqlError) {
			throw new NullDataException("NullData");
		}
	}
	public boolean register(String firstName, String lastName, int studentId, String id, String password) throws NullDataException,  ExecuteQueryException {
		String registerQuery = constant.getRegisterQuery(firstName, lastName, studentId, id, password);
		return super.create(registerQuery);
	}
	public boolean updateAccount(String usedId, String usedPassword, String newId, String newPassword) throws NullDataException, ExecuteQueryException {
		String updateStudentAccountQuery = constant.getUpdateStudentAccountQuery(usedId, usedPassword, newId, newPassword);
		return super.update(updateStudentAccountQuery);
	}
	public boolean deleteAccount(String firstName, String lastName, int studentId, String id, String password) throws ExecuteQueryException, NullDataException {
		String deleteStudentAccount = constant.getDeleteAccountQuery(firstName, lastName, studentId, id, password);
		if(super.delete(deleteStudentAccount) == 0)  throw new NullDataException("NullData");
		else return true;
	}
}
































