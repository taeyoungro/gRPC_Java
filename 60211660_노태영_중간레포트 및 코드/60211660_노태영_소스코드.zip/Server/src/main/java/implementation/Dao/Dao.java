package implementation.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;

public class Dao {
	String DB_CONNECT="jdbc:oracle:thin:@localhost:1521/xepdb1";
	private Connection connection;
	private Statement statement;
	
	public void connect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(DB_CONNECT, "CNSUSER", "tyro981009");	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public boolean create(String query) throws NullDataException, ExecuteQueryException{
		try {
			System.out.println(query);
			statement = connection.createStatement();
			int insertValueNumber = statement.executeUpdate(query);
			if(insertValueNumber == 0)  throw new NullDataException("NullData");
			else return true;
			} catch (SQLException sqlError) {
				throw new ExecuteQueryException(sqlError.getMessage());
			}
		}
	public ResultSet retrieve(String query) throws ExecuteQueryException, ServerErrorException {     
		try {
			System.out.println(query);
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			if(resultSet == null) throw new ServerErrorException("ServerError");
			if(resultSet.next()) return resultSet;
			else return resultSet;
			} catch (SQLException sqlError) {
				throw new ExecuteQueryException(sqlError.getMessage());
			}
		}
	public boolean update(String query) throws ExecuteQueryException, NullDataException {
		try {
			System.out.println(query);
			statement = connection.createStatement();
			int insertValueNumber = statement.executeUpdate(query);
			if(insertValueNumber == 0) throw new NullDataException("NullData");
			else return true;
			} catch (SQLException sqlError) {
				throw new ExecuteQueryException(sqlError.getMessage());
			}
	}
	public int delete(String query) throws ExecuteQueryException {
		System.out.println(query);
		try {
			statement = connection.createStatement();
			return statement.executeUpdate(query);
			} catch (SQLException sqlError) {
				throw new ExecuteQueryException(sqlError.getMessage());
			}
	}
}