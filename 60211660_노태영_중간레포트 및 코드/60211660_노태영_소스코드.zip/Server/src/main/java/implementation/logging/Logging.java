package implementation.logging;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logging {
	public boolean logging(String id, String process) {
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String now = simpleDateFormat.format(new Date());
			File file = null;
			if(process.equals("Student")) file = new File("FileData/StudentLogging");
			else if(process.equals("Professor") )file = new File("FileData/ProfessorLogging");
			else if(process.equals("Admin") )file = new File("FileData/AdminLogging");
			String loggingLine = id + " " + now;
			FileWriter fileWriter = new FileWriter(file, true);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

			bufferedWriter.write(loggingLine);
			bufferedWriter.newLine();
			bufferedWriter.close();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
}
