package implementation.impl;

import java.util.List;

import api.rpc.GetStudentServiceGrpc.GetStudentServiceImplBase;
import api.rpc.Student;
import api.rpc.StudentListRequest;
import api.rpc.StudentListResponse;
import implementation.Dao.StudentDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import implementation.exception.TokenException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class GetStudentForProfessorAndAdmin extends GetStudentServiceImplBase  {
	private StudentDao studentDao;
	private TokenGenerator tokenGenerator;
	
	public GetStudentForProfessorAndAdmin() {
		tokenGenerator = new TokenGenerator();
		 try {
			studentDao = new StudentDao();
		} catch (Exception e) {e.printStackTrace();}
	}
	@Override
	public void getStudentList(StudentListRequest request, StreamObserver<StudentListResponse> responseObserver) {
		StudentListResponse response = null;
		try {
			tokenGenerator.validateToken(request.getToken(), request.getProcess());
			List <Student> studentList = studentDao.getStudentList(request.getCondition(), request.getConditionValue());
			response = StudentListResponse.newBuilder().setResult("Success").addAllStudent(studentList).build();
		} catch(TokenException tokenError) {
			response = StudentListResponse.newBuilder().setResult(tokenError.getMessage()).build();
		} catch(NullDataException nullDataError) {
			response = StudentListResponse.newBuilder().setResult(nullDataError.getMessage()).build();
		} catch (ExecuteQueryException sqlError) {
			response = StudentListResponse.newBuilder().setResult("ServerError").build();
		} catch (ServerErrorException serverError) {
			response = StudentListResponse.newBuilder().setResult(serverError.getMessage()).build();
		} finally {
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
		
	}
}
