package implementation.impl;

import api.rpc.LoginRequest;
import api.rpc.LoginResponse;
import api.rpc.LoginServiceGrpc.LoginServiceImplBase;
import api.rpc.Professor;
import api.rpc.Student;
import api.rpc.Token;
import implementation.Dao.AccounDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import implementation.jwt.TokenGenerator;
import implementation.logging.Logging;
import io.grpc.stub.StreamObserver;

public class LoginForAllProcess extends LoginServiceImplBase{
	private AccounDao accountDao;
	private TokenGenerator tokenGenerator;
	private Logging logging;
	public LoginForAllProcess() {
		accountDao = new AccounDao();
		tokenGenerator = new TokenGenerator();
		logging = new Logging();
	}
	@Override
	public void login(LoginRequest request, StreamObserver<LoginResponse> responseObserver) {
		LoginResponse response = null;
		try {
			response = makeLoginResponse(request.getId(), request.getPassword(), request.getProcess());
			logging(request.getId(), request.getProcess());
		} catch (NullDataException nullDataError) {
			response = LoginResponse.newBuilder().setResult(nullDataError.getMessage()).build();
		} catch (ServerErrorException serverError) {
			response = LoginResponse.newBuilder().setResult(serverError.getMessage()).build();			
		} catch (ExecuteQueryException queryError) {
			response = LoginResponse.newBuilder().setResult("ServerError").build();	
		} finally {
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	private LoginResponse makeLoginResponse(String id, String password, String process) throws NullDataException, ServerErrorException, ExecuteQueryException {
		Object object= accountDao.login(id, password, process);
		Token token = tokenGenerator.generateToken(object);
		if(process.equals("Admin")) return LoginResponse.newBuilder().setToken(token).setResult("Success").build();
		else if(process.equals("Student")){
				Student student = (Student) object;
				return LoginResponse.newBuilder().setToken(token).setResult("Success")
						.setName(student.getFirstName()+student.getLastName()).setObjectId(student.getStudentId()).build();
		}
		else if(process.equals("Professor")){
				Professor professor = (Professor) object;
				return LoginResponse.newBuilder().setToken(token).setResult("Success")
						.setName(professor.getFirstName()+professor.getLastName()).setObjectId(professor.getProfessorId()).build();
		}
		else throw new ServerErrorException("ServerError");
	}
	private void logging(String id, String process) {
		for (int i = 0; i < 10; i++) {
			if (logging.logging(id, process)) break;
			else System.out.println(i + 1 + "번 로깅 실패/재반복");
		}
	}
}
