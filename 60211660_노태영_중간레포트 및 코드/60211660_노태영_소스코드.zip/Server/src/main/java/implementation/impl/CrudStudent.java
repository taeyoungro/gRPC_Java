package implementation.impl;

import api.rpc.CreateStudentRequest;
import api.rpc.CrudStudentServiceGrpc.CrudStudentServiceImplBase;
import api.rpc.DeleteStudentRequest;
import api.rpc.ResultResponse;
import api.rpc.UpdateStudentRequest;
import implementation.Dao.StudentDao;
import implementation.exception.TokenException;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class CrudStudent extends CrudStudentServiceImplBase{
	private StudentDao studentDao;
	private TokenGenerator tokenGenerator;
	private final String STUDENTID_PrimaryKey = "SYS_C008468";
	public CrudStudent() {
		studentDao = new StudentDao();
		tokenGenerator = new TokenGenerator();
	}
	@Override
	public void createStudent(CreateStudentRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.validateToken(request.getToken(), "Admin");
			if(studentDao.createStudent(request.getStudent())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if (sqlError.getMessage().contains(STUDENTID_PrimaryKey)) result = "AlreadyExistSameStudentId"; 
			else result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void deleteStudent(DeleteStudentRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.validateToken(request.getToken(), "Admin");
			if(studentDao.deleteStudent(request.getStudent())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	@Override
	public void updateStudent(UpdateStudentRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			tokenGenerator.validateToken(request.getToken(), "Admin");
			if(studentDao.updateStudent(request.getOriginStudent(), request.getNewStudent())) result = "Success";
		} catch (TokenException tokenError) {
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}