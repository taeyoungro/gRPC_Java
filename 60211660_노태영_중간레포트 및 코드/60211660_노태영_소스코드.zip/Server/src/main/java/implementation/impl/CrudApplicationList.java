package implementation.impl;

import java.util.List;
import api.rpc.Course;
import api.rpc.CrudApplicationRequest;
import api.rpc.ResultResponse;
import api.rpc.CrudApplicationServiceGrpc.CrudApplicationServiceImplBase;
import api.rpc.Student;
import implementation.Dao.ApplicationListDao;
import implementation.Dao.CourseDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import implementation.exception.TokenException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class CrudApplicationList extends CrudApplicationServiceImplBase{
	private ApplicationListDao applicationListDao;
	private CourseDao courseDao;
	private TokenGenerator tokenGenerator;
	
	public CrudApplicationList() {
		try {
			tokenGenerator = new TokenGenerator();
			tokenGenerator = new TokenGenerator();
			applicationListDao = new ApplicationListDao();
			courseDao = new CourseDao();
		}
		 catch (Exception e) {e.printStackTrace();}
	}
	@Override
	public void choiceNewCourse(CrudApplicationRequest request, StreamObserver<ResultResponse> responseObserver) {
		ResultResponse response = null;
		String result = null;
		try {
			Student student = tokenGenerator.getStudent(request.getToken());
			Course choiceCourse = request.getCourse();
			List<Course> applicationList = courseDao.getApplicationList(student.getStudentId());
			result = insertCourseInApplicationList(choiceCourse, applicationList, student);
		} catch (TokenException tokenError) {	
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {	
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} catch (ServerErrorException serverError) {
			result = serverError.getMessage();
		} finally {
			response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
	private String insertCourseInApplicationList(Course choiceCourse, List<Course> applicationList, Student student) throws NullDataException,  ExecuteQueryException, ServerErrorException {
		boolean noneOverMaximumCredit = student.getMaximumCredit() >= getApplicationCredit(applicationList) + choiceCourse.getCredit();
		boolean noneSameCourse = checkNoneSameCourse(applicationList, choiceCourse);
		boolean noneOverMaximumStudent = choiceCourse.getMaximumStudent() > choiceCourse.getNumberOfStudent();
		boolean attendedRequirementCourse = checkRequirementCourse(choiceCourse, student.getAttendedCourseList());
		boolean noneOverTwoReApplication = checkOverTwoReApplication(applicationList, student.getAttendedCourseList(), choiceCourse);

		if(noneSameCourse && noneOverMaximumCredit && noneOverMaximumStudent && attendedRequirementCourse && noneOverTwoReApplication) 
			return applicationListDao.insertCourseInApplicationList(student.getStudentId(), choiceCourse.getCourseId());
		else if(!noneOverMaximumCredit) throw new NullDataException("AlreadyFullMaximumCredit");
		else if(!noneSameCourse) throw new NullDataException("AlreadyExistInApplicationList");
		else if(!noneOverMaximumStudent) throw new NullDataException("AlreadyFullMaximumStudent");
		else if(!noneOverTwoReApplication) throw new NullDataException("OverTwoReApplication");
		else if(!attendedRequirementCourse) throw new NullDataException("RequirementExist");
		else throw new NullDataException("ServerError");
	}
	private int getApplicationCredit(List<Course> applicationList) {
		int applicationCredit = 0;
		for(int i = 0; i < applicationList.size(); i++) {applicationCredit += applicationList.get(i).getCredit();}
		return applicationCredit;
	}
	private boolean checkOverTwoReApplication(List<Course> applicationList, List<Course> attendedCourseList, Course choiceCourse) {
		boolean choiceIsInAttendedList = false;
		for(int i = 0; i < attendedCourseList.size(); i++) {
			if(attendedCourseList.get(i).getCourseId() == choiceCourse.getCourseId()) {
				choiceIsInAttendedList = true;
				break;
			}
		}
		if(!choiceIsInAttendedList) return true;
		int countReApplication = 0;
		for (int i = 0; i < attendedCourseList.size(); i++) {
			for (int j = 0; j < applicationList.size(); j++) { 
				if (attendedCourseList.get(i).getCourseId() == applicationList.get(j).getCourseId()) countReApplication++;
			}
		}
		return (countReApplication < 2);
	}
	private boolean checkRequirementCourse(Course choiceCourse, List<Course> attendedCourseList) {
		int firstRequirementCourseId = choiceCourse.getRequirement1();
		int secondRequirementCourseId = choiceCourse.getRequirement2();
		if(firstRequirementCourseId == 0) return true;
		else if(secondRequirementCourseId == 0) return loopingAttendedCourseList(attendedCourseList, firstRequirementCourseId);
		else {
			boolean firstRequirement = false;
			firstRequirement = loopingAttendedCourseList(attendedCourseList, firstRequirementCourseId);
			if(firstRequirement) loopingAttendedCourseList(attendedCourseList, secondRequirementCourseId);
		} return false;
	}
	private boolean loopingAttendedCourseList(List<Course> attendedCourseList, int requirementCourseId) {
		for(int i = 0; i < attendedCourseList.size(); i++) {
			if(attendedCourseList.get(i).getCourseId() == requirementCourseId) return true;
		} return false;
	}
	private boolean checkNoneSameCourse(List<Course> applicationList, Course choiceCourse) {
		for(int i = 0; i<applicationList.size(); i++) {
			if(applicationList.get(i).getCourseId()==choiceCourse.getCourseId()) return false;
		}
		return true;
	}
	@Override
	public void deleteApplication(CrudApplicationRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			Student student = tokenGenerator.getStudent(request.getToken());
			result = applicationListDao.deleteCourseInApplicationList(student.getStudentId(), request.getCourse().getCourseId());
		} catch (TokenException tokenError) {	
			result = tokenError.getMessage();
		} catch (NullDataException nullDataError) {	
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			result = "ServerError";
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}

















