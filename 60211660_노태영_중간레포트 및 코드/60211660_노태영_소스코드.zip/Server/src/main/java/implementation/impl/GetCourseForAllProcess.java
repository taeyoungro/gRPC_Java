package implementation.impl;

import java.util.ArrayList;
import java.util.List;
import api.rpc.Course;
import api.rpc.CourseListRequest;
import api.rpc.CourseListResponse;
import api.rpc.GetCourseServiceGrpc.GetCourseServiceImplBase;
import api.rpc.Student;
import api.rpc.Token;
import implementation.Dao.CourseDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import implementation.exception.TokenException;
import implementation.jwt.TokenGenerator;
import io.grpc.stub.StreamObserver;

public class GetCourseForAllProcess extends GetCourseServiceImplBase  {
	private CourseDao courseDao;
	private TokenGenerator tokenGenerator;
	
	public GetCourseForAllProcess() {
		tokenGenerator = new TokenGenerator();
		 try {
			courseDao = new CourseDao();
		} catch (Exception e) {e.printStackTrace();}
	}
	@Override	
	public void getCourseList(CourseListRequest request, StreamObserver<CourseListResponse> responseObserver) {
		CourseListResponse response = null;
		try {
			Token token = request.getToken();
			List<Course> courseList = new ArrayList<Course> ();
			tokenGenerator.validateToken(token, request.getProcess());

			if(request.getIsAttendedList()) {
				courseList = tokenGenerator.getStudent(token).getAttendedCourseList();
				if(courseList.size() == 0) throw new NullDataException("NullData");
			} else if(request.getIsApplicationList()) {
				Student student = tokenGenerator.getStudent(token);
				courseList =  courseDao.getApplicationList(student.getStudentId());
			} else courseList = courseDao.getCourseList(request.getCondition(), request.getConditionValue());	
			
			if(courseList == null) throw new NullDataException("NullData");
			response = CourseListResponse.newBuilder().setResult("Success").addAllCourse(courseList).build();
		} catch (TokenException tokenError) {
			response = CourseListResponse.newBuilder().setResult(tokenError.getMessage()).build();
		} catch (NullDataException nullDataError) {
			response = CourseListResponse.newBuilder().setResult(nullDataError.getMessage()).build();
		} catch (ExecuteQueryException sqlError) {
			response = CourseListResponse.newBuilder().setResult("ServerError").build();
		} catch (ServerErrorException serverError) {
			response = CourseListResponse.newBuilder().setResult(serverError.getMessage()).build();
		}finally {
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
//	private List<Course> courseListResponse(CourseListRequest request) throws NullDataException, ExecuteQueryException, ServerErrorException {
//		return courseDao.getCourseList(request.getCondition(), request.getConditionValue());
//	}
//	private List<Course> applicationListResponse(Token token) throws NullDataException, ServerErrorException, ExecuteQueryException {
//		Student student = tokenGenerator.getStudent(token);
//		return courseDao.getApplicationList(student.getStudentId());
//	}
}
