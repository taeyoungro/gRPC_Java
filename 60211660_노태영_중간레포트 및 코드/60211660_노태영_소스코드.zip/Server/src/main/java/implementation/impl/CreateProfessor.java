package implementation.impl;

import api.rpc.CrudProfessorServiceGrpc.CrudProfessorServiceImplBase;
import api.rpc.ResultResponse;
import api.rpc.CreateProfessorRequest;
import implementation.Dao.ProfessorDao;
import implementation.exception.ExecuteQueryException;
import implementation.exception.NullDataException;
import implementation.exception.ServerErrorException;
import io.grpc.stub.StreamObserver;;

public class CreateProfessor extends CrudProfessorServiceImplBase{
	private ProfessorDao professorDao;
	private final String PROFESSORID_PrimaryKey = "SYS_C008449";
	private final String ACCOUNTID_PrimaryKey = "SYS_C008452";
	public CreateProfessor() {
		professorDao = new ProfessorDao();
	}
	@Override
	public void createProfessor(CreateProfessorRequest request, StreamObserver<ResultResponse> responseObserver) {
		String result = null;
		try {
			if(professorDao.createProfessor(request.getProfessor())) result = "Success";
			else result = "ServerError";
		} catch (NullDataException nullDataError) {
			result = nullDataError.getMessage();
		} catch (ExecuteQueryException sqlError) {
			if(sqlError.getMessage().contains(PROFESSORID_PrimaryKey)) result = "AlreadtExistSameProfessorId";
			else if(sqlError.getMessage().contains(ACCOUNTID_PrimaryKey)) result = "AlreadtExistSameId";
			else result = "ServerError";
		} catch (ServerErrorException serverError) {
			result = serverError.getMessage();
		} finally {
			ResultResponse response = ResultResponse.newBuilder().setResult(result).build();
			responseObserver.onNext(response);
			responseObserver.onCompleted();
		}
	}
}
