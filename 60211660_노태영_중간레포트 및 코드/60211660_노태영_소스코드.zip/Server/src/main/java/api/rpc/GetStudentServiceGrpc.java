package api.rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ServiceForCNS.proto")
public final class GetStudentServiceGrpc {

  private GetStudentServiceGrpc() {}

  public static final String SERVICE_NAME = "api.rpc.GetStudentService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<api.rpc.StudentListRequest,
      api.rpc.StudentListResponse> getGetStudentListMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetStudentList",
      requestType = api.rpc.StudentListRequest.class,
      responseType = api.rpc.StudentListResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.StudentListRequest,
      api.rpc.StudentListResponse> getGetStudentListMethod() {
    io.grpc.MethodDescriptor<api.rpc.StudentListRequest, api.rpc.StudentListResponse> getGetStudentListMethod;
    if ((getGetStudentListMethod = GetStudentServiceGrpc.getGetStudentListMethod) == null) {
      synchronized (GetStudentServiceGrpc.class) {
        if ((getGetStudentListMethod = GetStudentServiceGrpc.getGetStudentListMethod) == null) {
          GetStudentServiceGrpc.getGetStudentListMethod = getGetStudentListMethod = 
              io.grpc.MethodDescriptor.<api.rpc.StudentListRequest, api.rpc.StudentListResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.GetStudentService", "GetStudentList"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.StudentListRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.StudentListResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new GetStudentServiceMethodDescriptorSupplier("GetStudentList"))
                  .build();
          }
        }
     }
     return getGetStudentListMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static GetStudentServiceStub newStub(io.grpc.Channel channel) {
    return new GetStudentServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static GetStudentServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new GetStudentServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static GetStudentServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new GetStudentServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class GetStudentServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void getStudentList(api.rpc.StudentListRequest request,
        io.grpc.stub.StreamObserver<api.rpc.StudentListResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetStudentListMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetStudentListMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.StudentListRequest,
                api.rpc.StudentListResponse>(
                  this, METHODID_GET_STUDENT_LIST)))
          .build();
    }
  }

  /**
   */
  public static final class GetStudentServiceStub extends io.grpc.stub.AbstractStub<GetStudentServiceStub> {
    private GetStudentServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private GetStudentServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GetStudentServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new GetStudentServiceStub(channel, callOptions);
    }

    /**
     */
    public void getStudentList(api.rpc.StudentListRequest request,
        io.grpc.stub.StreamObserver<api.rpc.StudentListResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetStudentListMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class GetStudentServiceBlockingStub extends io.grpc.stub.AbstractStub<GetStudentServiceBlockingStub> {
    private GetStudentServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private GetStudentServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GetStudentServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new GetStudentServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public api.rpc.StudentListResponse getStudentList(api.rpc.StudentListRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetStudentListMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class GetStudentServiceFutureStub extends io.grpc.stub.AbstractStub<GetStudentServiceFutureStub> {
    private GetStudentServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private GetStudentServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected GetStudentServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new GetStudentServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.StudentListResponse> getStudentList(
        api.rpc.StudentListRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetStudentListMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_STUDENT_LIST = 0;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final GetStudentServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(GetStudentServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_STUDENT_LIST:
          serviceImpl.getStudentList((api.rpc.StudentListRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.StudentListResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class GetStudentServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    GetStudentServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return api.rpc.ServiceForCNS.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("GetStudentService");
    }
  }

  private static final class GetStudentServiceFileDescriptorSupplier
      extends GetStudentServiceBaseDescriptorSupplier {
    GetStudentServiceFileDescriptorSupplier() {}
  }

  private static final class GetStudentServiceMethodDescriptorSupplier
      extends GetStudentServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    GetStudentServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (GetStudentServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new GetStudentServiceFileDescriptorSupplier())
              .addMethod(getGetStudentListMethod())
              .build();
        }
      }
    }
    return result;
  }
}
