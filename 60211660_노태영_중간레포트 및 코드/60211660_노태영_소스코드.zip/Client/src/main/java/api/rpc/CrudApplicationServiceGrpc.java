package api.rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ServiceForClient.proto")
public final class CrudApplicationServiceGrpc {

  private CrudApplicationServiceGrpc() {}

  public static final String SERVICE_NAME = "api.rpc.CrudApplicationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest,
      api.rpc.ResultResponse> getChoiceNewCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "choiceNewCourse",
      requestType = api.rpc.CrudApplicationRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest,
      api.rpc.ResultResponse> getChoiceNewCourseMethod() {
    io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest, api.rpc.ResultResponse> getChoiceNewCourseMethod;
    if ((getChoiceNewCourseMethod = CrudApplicationServiceGrpc.getChoiceNewCourseMethod) == null) {
      synchronized (CrudApplicationServiceGrpc.class) {
        if ((getChoiceNewCourseMethod = CrudApplicationServiceGrpc.getChoiceNewCourseMethod) == null) {
          CrudApplicationServiceGrpc.getChoiceNewCourseMethod = getChoiceNewCourseMethod = 
              io.grpc.MethodDescriptor.<api.rpc.CrudApplicationRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudApplicationService", "choiceNewCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.CrudApplicationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudApplicationServiceMethodDescriptorSupplier("choiceNewCourse"))
                  .build();
          }
        }
     }
     return getChoiceNewCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest,
      api.rpc.ResultResponse> getDeleteApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteApplication",
      requestType = api.rpc.CrudApplicationRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest,
      api.rpc.ResultResponse> getDeleteApplicationMethod() {
    io.grpc.MethodDescriptor<api.rpc.CrudApplicationRequest, api.rpc.ResultResponse> getDeleteApplicationMethod;
    if ((getDeleteApplicationMethod = CrudApplicationServiceGrpc.getDeleteApplicationMethod) == null) {
      synchronized (CrudApplicationServiceGrpc.class) {
        if ((getDeleteApplicationMethod = CrudApplicationServiceGrpc.getDeleteApplicationMethod) == null) {
          CrudApplicationServiceGrpc.getDeleteApplicationMethod = getDeleteApplicationMethod = 
              io.grpc.MethodDescriptor.<api.rpc.CrudApplicationRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudApplicationService", "DeleteApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.CrudApplicationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudApplicationServiceMethodDescriptorSupplier("DeleteApplication"))
                  .build();
          }
        }
     }
     return getDeleteApplicationMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CrudApplicationServiceStub newStub(io.grpc.Channel channel) {
    return new CrudApplicationServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CrudApplicationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new CrudApplicationServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CrudApplicationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new CrudApplicationServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class CrudApplicationServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void choiceNewCourse(api.rpc.CrudApplicationRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getChoiceNewCourseMethod(), responseObserver);
    }

    /**
     */
    public void deleteApplication(api.rpc.CrudApplicationRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteApplicationMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getChoiceNewCourseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.CrudApplicationRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_CHOICE_NEW_COURSE)))
          .addMethod(
            getDeleteApplicationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.CrudApplicationRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_DELETE_APPLICATION)))
          .build();
    }
  }

  /**
   */
  public static final class CrudApplicationServiceStub extends io.grpc.stub.AbstractStub<CrudApplicationServiceStub> {
    private CrudApplicationServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudApplicationServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudApplicationServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudApplicationServiceStub(channel, callOptions);
    }

    /**
     */
    public void choiceNewCourse(api.rpc.CrudApplicationRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getChoiceNewCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteApplication(api.rpc.CrudApplicationRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteApplicationMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class CrudApplicationServiceBlockingStub extends io.grpc.stub.AbstractStub<CrudApplicationServiceBlockingStub> {
    private CrudApplicationServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudApplicationServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudApplicationServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudApplicationServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public api.rpc.ResultResponse choiceNewCourse(api.rpc.CrudApplicationRequest request) {
      return blockingUnaryCall(
          getChannel(), getChoiceNewCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse deleteApplication(api.rpc.CrudApplicationRequest request) {
      return blockingUnaryCall(
          getChannel(), getDeleteApplicationMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class CrudApplicationServiceFutureStub extends io.grpc.stub.AbstractStub<CrudApplicationServiceFutureStub> {
    private CrudApplicationServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudApplicationServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudApplicationServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudApplicationServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> choiceNewCourse(
        api.rpc.CrudApplicationRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getChoiceNewCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> deleteApplication(
        api.rpc.CrudApplicationRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteApplicationMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CHOICE_NEW_COURSE = 0;
  private static final int METHODID_DELETE_APPLICATION = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final CrudApplicationServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(CrudApplicationServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CHOICE_NEW_COURSE:
          serviceImpl.choiceNewCourse((api.rpc.CrudApplicationRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_DELETE_APPLICATION:
          serviceImpl.deleteApplication((api.rpc.CrudApplicationRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class CrudApplicationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CrudApplicationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return api.rpc.ServiceForClient.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CrudApplicationService");
    }
  }

  private static final class CrudApplicationServiceFileDescriptorSupplier
      extends CrudApplicationServiceBaseDescriptorSupplier {
    CrudApplicationServiceFileDescriptorSupplier() {}
  }

  private static final class CrudApplicationServiceMethodDescriptorSupplier
      extends CrudApplicationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    CrudApplicationServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CrudApplicationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CrudApplicationServiceFileDescriptorSupplier())
              .addMethod(getChoiceNewCourseMethod())
              .addMethod(getDeleteApplicationMethod())
              .build();
        }
      }
    }
    return result;
  }
}
