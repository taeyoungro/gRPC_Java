package api.rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.15.0)",
    comments = "Source: ServiceForClient.proto")
public final class CrudCourseServiceGrpc {

  private CrudCourseServiceGrpc() {}

  public static final String SERVICE_NAME = "api.rpc.CrudCourseService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<api.rpc.CreateCourseRequest,
      api.rpc.ResultResponse> getCreatCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreatCourse",
      requestType = api.rpc.CreateCourseRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.CreateCourseRequest,
      api.rpc.ResultResponse> getCreatCourseMethod() {
    io.grpc.MethodDescriptor<api.rpc.CreateCourseRequest, api.rpc.ResultResponse> getCreatCourseMethod;
    if ((getCreatCourseMethod = CrudCourseServiceGrpc.getCreatCourseMethod) == null) {
      synchronized (CrudCourseServiceGrpc.class) {
        if ((getCreatCourseMethod = CrudCourseServiceGrpc.getCreatCourseMethod) == null) {
          CrudCourseServiceGrpc.getCreatCourseMethod = getCreatCourseMethod = 
              io.grpc.MethodDescriptor.<api.rpc.CreateCourseRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudCourseService", "CreatCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.CreateCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudCourseServiceMethodDescriptorSupplier("CreatCourse"))
                  .build();
          }
        }
     }
     return getCreatCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.DeleteCourseRequest,
      api.rpc.ResultResponse> getDeleteCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteCourse",
      requestType = api.rpc.DeleteCourseRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.DeleteCourseRequest,
      api.rpc.ResultResponse> getDeleteCourseMethod() {
    io.grpc.MethodDescriptor<api.rpc.DeleteCourseRequest, api.rpc.ResultResponse> getDeleteCourseMethod;
    if ((getDeleteCourseMethod = CrudCourseServiceGrpc.getDeleteCourseMethod) == null) {
      synchronized (CrudCourseServiceGrpc.class) {
        if ((getDeleteCourseMethod = CrudCourseServiceGrpc.getDeleteCourseMethod) == null) {
          CrudCourseServiceGrpc.getDeleteCourseMethod = getDeleteCourseMethod = 
              io.grpc.MethodDescriptor.<api.rpc.DeleteCourseRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudCourseService", "DeleteCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.DeleteCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudCourseServiceMethodDescriptorSupplier("DeleteCourse"))
                  .build();
          }
        }
     }
     return getDeleteCourseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<api.rpc.UpdateCourseRequest,
      api.rpc.ResultResponse> getUpdateCourseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateCourse",
      requestType = api.rpc.UpdateCourseRequest.class,
      responseType = api.rpc.ResultResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<api.rpc.UpdateCourseRequest,
      api.rpc.ResultResponse> getUpdateCourseMethod() {
    io.grpc.MethodDescriptor<api.rpc.UpdateCourseRequest, api.rpc.ResultResponse> getUpdateCourseMethod;
    if ((getUpdateCourseMethod = CrudCourseServiceGrpc.getUpdateCourseMethod) == null) {
      synchronized (CrudCourseServiceGrpc.class) {
        if ((getUpdateCourseMethod = CrudCourseServiceGrpc.getUpdateCourseMethod) == null) {
          CrudCourseServiceGrpc.getUpdateCourseMethod = getUpdateCourseMethod = 
              io.grpc.MethodDescriptor.<api.rpc.UpdateCourseRequest, api.rpc.ResultResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "api.rpc.CrudCourseService", "UpdateCourse"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.UpdateCourseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  api.rpc.ResultResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new CrudCourseServiceMethodDescriptorSupplier("UpdateCourse"))
                  .build();
          }
        }
     }
     return getUpdateCourseMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CrudCourseServiceStub newStub(io.grpc.Channel channel) {
    return new CrudCourseServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CrudCourseServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new CrudCourseServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CrudCourseServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new CrudCourseServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class CrudCourseServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void creatCourse(api.rpc.CreateCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCreatCourseMethod(), responseObserver);
    }

    /**
     */
    public void deleteCourse(api.rpc.DeleteCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteCourseMethod(), responseObserver);
    }

    /**
     */
    public void updateCourse(api.rpc.UpdateCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateCourseMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreatCourseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.CreateCourseRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_CREAT_COURSE)))
          .addMethod(
            getDeleteCourseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.DeleteCourseRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_DELETE_COURSE)))
          .addMethod(
            getUpdateCourseMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                api.rpc.UpdateCourseRequest,
                api.rpc.ResultResponse>(
                  this, METHODID_UPDATE_COURSE)))
          .build();
    }
  }

  /**
   */
  public static final class CrudCourseServiceStub extends io.grpc.stub.AbstractStub<CrudCourseServiceStub> {
    private CrudCourseServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudCourseServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudCourseServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudCourseServiceStub(channel, callOptions);
    }

    /**
     */
    public void creatCourse(api.rpc.CreateCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreatCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteCourse(api.rpc.DeleteCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDeleteCourseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateCourse(api.rpc.UpdateCourseRequest request,
        io.grpc.stub.StreamObserver<api.rpc.ResultResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateCourseMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class CrudCourseServiceBlockingStub extends io.grpc.stub.AbstractStub<CrudCourseServiceBlockingStub> {
    private CrudCourseServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudCourseServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudCourseServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudCourseServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public api.rpc.ResultResponse creatCourse(api.rpc.CreateCourseRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreatCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse deleteCourse(api.rpc.DeleteCourseRequest request) {
      return blockingUnaryCall(
          getChannel(), getDeleteCourseMethod(), getCallOptions(), request);
    }

    /**
     */
    public api.rpc.ResultResponse updateCourse(api.rpc.UpdateCourseRequest request) {
      return blockingUnaryCall(
          getChannel(), getUpdateCourseMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class CrudCourseServiceFutureStub extends io.grpc.stub.AbstractStub<CrudCourseServiceFutureStub> {
    private CrudCourseServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private CrudCourseServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CrudCourseServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new CrudCourseServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> creatCourse(
        api.rpc.CreateCourseRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreatCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> deleteCourse(
        api.rpc.DeleteCourseRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDeleteCourseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<api.rpc.ResultResponse> updateCourse(
        api.rpc.UpdateCourseRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateCourseMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREAT_COURSE = 0;
  private static final int METHODID_DELETE_COURSE = 1;
  private static final int METHODID_UPDATE_COURSE = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final CrudCourseServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(CrudCourseServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREAT_COURSE:
          serviceImpl.creatCourse((api.rpc.CreateCourseRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_DELETE_COURSE:
          serviceImpl.deleteCourse((api.rpc.DeleteCourseRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        case METHODID_UPDATE_COURSE:
          serviceImpl.updateCourse((api.rpc.UpdateCourseRequest) request,
              (io.grpc.stub.StreamObserver<api.rpc.ResultResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class CrudCourseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CrudCourseServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return api.rpc.ServiceForClient.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CrudCourseService");
    }
  }

  private static final class CrudCourseServiceFileDescriptorSupplier
      extends CrudCourseServiceBaseDescriptorSupplier {
    CrudCourseServiceFileDescriptorSupplier() {}
  }

  private static final class CrudCourseServiceMethodDescriptorSupplier
      extends CrudCourseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    CrudCourseServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CrudCourseServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CrudCourseServiceFileDescriptorSupplier())
              .addMethod(getCreatCourseMethod())
              .addMethod(getDeleteCourseMethod())
              .addMethod(getUpdateCourseMethod())
              .build();
        }
      }
    }
    return result;
  }
}
