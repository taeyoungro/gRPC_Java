package implemenataion.administrator_process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import api.rpc.Admin;
import api.rpc.Course;
import api.rpc.Token;
import api.rpc.CourseListRequest;
import api.rpc.CourseListResponse;
import api.rpc.CreateAdminRequest;
import api.rpc.CreateStudentRequest;
import api.rpc.CrudAdminServiceGrpc;
import api.rpc.GetCourseServiceGrpc;
import api.rpc.GetStudentServiceGrpc;
import api.rpc.LoginRequest;
import api.rpc.LoginResponse;
import api.rpc.LoginServiceGrpc;
import api.rpc.ResultResponse;
import api.rpc.Student;
import api.rpc.StudentListRequest;
import api.rpc.StudentListResponse;
import api.rpc.UpdateStudentRequest;
import api.rpc.CrudStudentServiceGrpc;
import api.rpc.DeleteStudentRequest;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

public class AdminProgram {
	private ManagedChannel channel;
	private String conditionValue;
	private Token token;
	private LoginServiceGrpc.LoginServiceBlockingStub  loginStub;
	private CrudAdminServiceGrpc.CrudAdminServiceBlockingStub  registerStub;
	private GetStudentServiceGrpc.GetStudentServiceBlockingStub getStudentStub;
	private GetCourseServiceGrpc.GetCourseServiceBlockingStub getCourseStub;
	private CrudStudentServiceGrpc.CrudStudentServiceBlockingStub crudStudentStub;
	
	public AdminProgram() {
		channel = ManagedChannelBuilder.forAddress("localhost", 9090).usePlaintext().build();
		loginStub = LoginServiceGrpc.newBlockingStub(channel);
		registerStub  = CrudAdminServiceGrpc.newBlockingStub(channel);
		getCourseStub = GetCourseServiceGrpc.newBlockingStub(channel);
		getStudentStub = GetStudentServiceGrpc.newBlockingStub(channel);
		crudStudentStub = CrudStudentServiceGrpc.newBlockingStub(channel);
	}
	
	public static void main(String[] args) {	
		BufferedReader objectReader = new BufferedReader(new InputStreamReader(System.in));
		AdminProgram main = new AdminProgram();
		System.out.println("본래 관리자 계정과 교수 계정을 생성하는 기능은 없으나");
		System.out.println("코드를 테스트하실 때 DDL만을 제출하여 테스트시 admin로그인과 교수 프로그램의 로그인이 수행되지 않기 때문에");
		System.out.println("교수, 관리자 회원가입 기능을 추가했습니다. 데이터 무결성이 지켜지지 않아 동일한 ID나 동일한 ProfessorId를 사용할 경우");
		System.out.println("무결성 오류가 발생허가나");
		System.out.println("무결성 오류를 알리는 것이 아닌 서버 오류를 알리는 점 양해부탁드립니다.");
		main.firtMenu(objectReader);
	}
	
	private void firtMenu(BufferedReader objectReader) {
		while (true) {
			try {
				System.out.println("*********************MENU*********************");
				System.out.println("1: 관리자 로그인");
				System.out.println("2: 관리자 생성");
				String choice = objectReader.readLine().trim();
				switch (choice) {
				case "1":
					loginInput(objectReader);
					break;
				case "2":
					registerInput(objectReader);
					break;
				}
			} catch (StatusRuntimeException e) {System.out.println("서버 오류입니다. 잠시후 다시 이용해주세요");}
			  catch (IOException e) {e.printStackTrace();}
		}
	}
	private void registerInput(BufferedReader objectReader) throws IOException {
		System.out.println("*********************회원가입*********************");
		System.out.print("관리자 ID: ");
		String id = objectReader.readLine().trim();
		System.out.print("관리자 Password: ");
		String password = objectReader.readLine().trim();
		register(id, password, objectReader);
	}

	private void register(String id, String password, BufferedReader objectReader) throws IOException {
		Admin admin = Admin.newBuilder().setId(id).setPassword(password).build();
		CreateAdminRequest request = CreateAdminRequest.newBuilder().setAdmin(admin).build();
		ResultResponse response = registerStub.createAdmin(request);
		String result = response.getResult();
		if(result.equals("Success")) System.out.println("회원가입에 성공했습니다.");
		else if(result.equals("NullData")) System.out.println("회원가입에 실패했습니다. 다시 시도해주세요");
		else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private void loginInput(BufferedReader objectReader) throws IOException {
		System.out.println("*********************LOGIN*********************");
		System.out.print("관리자 ID: ");
		String id = objectReader.readLine().trim();
		System.out.print("관리자 Password: ");
		String password = objectReader.readLine().trim();
		login(id, password, objectReader);
	}
	private void login(String id, String password, BufferedReader objectReader) throws IOException {
		LoginRequest request = LoginRequest.newBuilder().setId(id).setPassword(password).setProcess("Admin").build();
		LoginResponse response = loginStub.login(request);
		String result = response.getResult();
		if(result.equals("Success")) {token = response.getToken(); adminMenu(objectReader);}
		else if(result.equals("NullData")) loginFail(objectReader);
		else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}

	private void loginFail(BufferedReader objectReader) throws IOException {
		System.out.println("해당 관리자 계정이 존재하지 않습니다");
		System.out.println("재로그인 하시겠습니까?");
		System.out.println("1: 재로그인");
		System.out.println("X: 시스템 종료");
		System.out.print("입력: ");
		String choice = objectReader.readLine().trim();
		switch (choice){
		case"1" :
			loginInput(objectReader);
			break;
		case"X" :
			System.exit(0);
		}
	}
	private void adminMenu(BufferedReader objectReader) {
		try {
			while(true) {
				printMenu();
				String choiceMenu = objectReader.readLine().trim();
				switch(choiceMenu) {
				case "1" :
					setStudentListCondition(objectReader);
					break;
				case "2":
					setCourseListCondition(objectReader); // 조건에 따라서 강좌 출력
					break;
				case "3":
					createStudentEntity(objectReader);
					break;
				case "4":
					deleteStudentEntity(objectReader);
					break;
				case "5":
					updateStudentEntity(objectReader);
					break;
				}
			}
		} catch (IOException e) {e.printStackTrace();}
	}
	private  void printMenu() {
		System.out.println("*********************MENU********************");
		System.out.println("1: 학생리스트 출력");
		System.out.println("2: 강좌리스트 출력");
		System.out.println("3: 학생 추가하기");
		System.out.println("4: 학생 삭제하기");
		System.out.println("5: 학생 수정하기");
		System.out.print("입력: ");
	}
	private void setStudentListCondition(BufferedReader objectReader) throws IOException {
		out:while(true) {
			printStudentListCondition();
			String choiceCondition = objectReader.readLine().trim();
			switch (choiceCondition) {
			case "1":
				firstNameCondition(objectReader);
				break;
			case "2":
				departmentCondition(objectReader);
				break;
			case "3":
				studentScoreCondition(objectReader);
				break;
			case "4":
				genderCondition(objectReader);
				break;
			case "5":
				getStudentList("", "");
				break;
			case "X":
				break out;
			}
		}
	}
	public void printStudentListCondition() {
		System.out.println("*********************학생검색 조건*********************");
		System.out.println("1: 성씨");
		System.out.println("2: 학과");
		System.out.println("3: 학점");
		System.out.println("4: 성별");
		System.out.println("5: 전체학생");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}
	private void firstNameCondition(BufferedReader objectReader) throws IOException {
		System.out.println("검색할 성씨를 입력하세요. (Kim, Park ...)");
		System.out.print("입력: ");
		conditionValue = objectReader.readLine().trim();
		getStudentList("FIRSTNAME", conditionValue);
	}
	private void departmentCondition(BufferedReader objectReader) throws IOException {
		out:while(true) {
			System.out.println("밑에 보기중 검색할 학과를 입력하세요.");
			System.out.println("(CS, EE, ME)");
			System.out.print("입력: ");
			conditionValue = objectReader.readLine().trim();
			if(conditionValue.equals("CS")||conditionValue.equals("EE")||conditionValue.equals("ME")) {
				getStudentList("DEPARTMENT", conditionValue);
				break;
			}else {
				String choiceMenu = inputError(objectReader);
				switch(choiceMenu) {
				case "1" :
					break;
				case "2" :
					break out;
				}
			}
		}
	}
	private void studentScoreCondition(BufferedReader objectReader)throws IOException {
		 while (true) {
			printStudentScoreCondition();
			conditionValue = objectReader.readLine().trim();
			if (conditionValue.equals("1") || conditionValue.equals("2") || conditionValue.equals("3") || conditionValue.equals("4")|| conditionValue.equals("5")) {
				getStudentList("SCORE", conditionValue);
				break;
			}
		}
	}
	private void printStudentScoreCondition() {
		System.out.println("검색할 학생들의 학점을 선택하세요.");
		System.out.println("1: 0.0 <= X < 1.0");
		System.out.println("2: 1.0 <= X < 2.0");
		System.out.println("3: 2.0 <= X < 3.0");
		System.out.println("4: 3.0 <= X < 4.0");
		System.out.println("5: 4.0 <= X < 4.5");
		System.out.print("입력: ");
	}
	private void genderCondition(BufferedReader objectReader) throws IOException {
			printGenderCondition();
			conditionValue = objectReader.readLine().trim();
			switch(conditionValue) {
			case"1":
				conditionValue = "male";
				getStudentList("GENDER", conditionValue);
				break;
			case"2":
				conditionValue = "female";
				getStudentList("GENDER", conditionValue);
				break;
			case"X":
				break;
			}
	}
	private void printGenderCondition() {
		System.out.println("성별을 선택해주세요.");
		System.out.println("1: 남자");
		System.out.println("2: 여자");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}	
	private void setCourseListCondition(BufferedReader objectReader) throws IOException {
		out: while(true){
			printCourseListCondition();
			String choiceCondition = objectReader.readLine().trim();
		    switch(choiceCondition) {
		    case "1":
		    	creditCondition(objectReader);
		    	break;
		    case "2":
		    	requirementCondition(objectReader);
		    	break;
		    case "3":
		    	studentNumberCondition(objectReader);
		    	break;
		    case "4":
		    	getCourseList("", "");
		    	break;
		    case "X":
		    	break out;
		    }
		}
	}
	private void printCourseListCondition() {
		System.out.println("*********************강좌검색 조건*********************");
		System.out.println("1: 학점");
		System.out.println("2: 선수과목 유뮤");
		System.out.println("3: 신청학생 수");
		System.out.println("4: 모든 강좌");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}
	private void creditCondition(BufferedReader objectReader) throws IOException {
			printCreditCondition();
			String condition = objectReader.readLine().trim();
			switch(condition) {
			case "1":
				getCourseList("CREDIT", condition);
				break;
			case "2":
				getCourseList("CREDIT", condition);
				break;
			case "3":
				getCourseList("CREDIT", condition);
				break;
			case "X":
				break;
		}
	}
	private void printCreditCondition() {
		System.out.println("1: 1학점");
		System.out.println("2: 2학점");
		System.out.println("3: 3학점");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}

	private void requirementCondition(BufferedReader objectReader) throws IOException {
		prindRequirementCondition();
		String condition = objectReader.readLine().trim();
		switch (condition) {
		case "1":
			getCourseList("REQUIREMENT1", "NotNull");
			break;
		case "2":
			getCourseList("REQUIREMENT1", "Null");
			break;
		case "X":
			break;
		}

	}
	private void prindRequirementCondition() {
		System.out.println("1: 선수과목 O");
		System.out.println("2: 선수과목 X");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}

	private void studentNumberCondition(BufferedReader objectReader) throws IOException {
		printNumberOfApplicationCondition();
		String condition = objectReader.readLine().trim();
		switch (condition) {
		case "1":
			getCourseList("NUMBEROFSTUDENT", "0");
			break;
		case "2":
			getCourseList("NUMBEROFSTUDENT", "10");
			break;
		case "3":
			getCourseList("NUMBEROFSTUDENT", "20");
			break;
		case "4":
			getCourseList("NUMBEROFSTUDENT", "30");
			break;
		case "X":
			break;
		}
	}
	private void printNumberOfApplicationCondition() {
		System.out.println("강좌신청 학생 수");
		System.out.println("1: 0~10");
		System.out.println("2: 10~20");
		System.out.println("3: 20~30");
		System.out.println("4: 30~40");
		System.out.println("X: 나가기");
		System.out.print("입력: ");
	}
	private void getCourseList(String choiceCondition, String condition) throws IOException {
		CourseListRequest request = CourseListRequest.newBuilder().setToken(token).setProcess("Admin")
				.setCondition(choiceCondition).setConditionValue(condition).build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		String result = response.getResult();
		if(result.equals("Success")) {
			List<Course> list = response.getCourseList();
			System.out.println("해당 조건의 강좌입니다.");
			System.out.println(printCourseList(list));
		}
		else if(result.equals("NullData")) System.out.println("해당 조건의 강좌가 없습니다");
		else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 잠시후 다시 로그인해주세요.");
	}
	private String printCourseList(List<Course> list) {
		String sList = "";
		for (int i = 0; i < list.size(); i++) {
			Course course = list.get(i);
			sList += i+1 + "번 강좌 -->> " +
					"강좌명: " + course.getName() + ", 강좌ID: " + course.getCourseId() + 
					", REQUIREMENT1: " + course.getRequirement1() + ", REQUIREMENT2: " + course.getRequirement2() + 
					", 학점: " + course.getCredit() + ", 교수이름: " + course.getProfessorName() + 
					", 교수ID: " + course.getProfessorId() + ", 최대수강자수: " + course.getMaximumStudent() + 
					", 신청 학생수: " + course.getNumberOfStudent() +  "\n";
		} return sList;
	}
	private List<Student> getStudentList(String condtion,String conditionValue) {
		StudentListRequest request = StudentListRequest.newBuilder().setToken(token).setCondition(condtion).setConditionValue(conditionValue).setProcess("Admin").build();
		StudentListResponse response = getStudentStub.getStudentList(request);
		String result = response.getResult();
		List<Student> studentList = response.getStudentList();
		
		if(result.equals("Success")) printStudentList(studentList);
		else if(result.equals("NullData")) System.out.println("해당 조건의 학생이 없습니다");
		else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		return studentList;
	}
	private void printStudentList(List<Student> list) {
		String sList = "";
		if(list.size() == 0) System.out.println("해당 조건의 학생이 없습니다");
		else {
			System.out.println("해당 조건의 학생입니다.");
			for (int i = 0; i < list.size(); i++) {
				sList +=  i+1 + "번 학생 -->> " +
						"이름: " + list.get(i).getFirstName() + list.get(i).getLastName() + ", 학번: " + list.get(i).getStudentId() + 
						", 학과: " + list.get(i).getDepartment() + ", 성별: " + list.get(i).getGender() + 
						", 학점: " + list.get(i).getScore() + ", 신청가능학점: " + list.get(i).getMaximumCredit() + "\n";
			} 
			System.out.println(sList);
		}
	}
	
	private void createStudentEntity(BufferedReader objectReader) throws IOException {
		System.out.println("학생정보를 입력하세요");
		System.out.print("성씨: ");
		String firstName = objectReader.readLine().trim();
		System.out.print("이름: ");
		String lastName = objectReader.readLine().trim();	
		System.out.print("(8자리)학번: ");
		int studentId = setStudentId(objectReader);
		String department = setDepartment(objectReader);
		String gender = setGender(objectReader);
		Student student = Student.newBuilder()
				.setFirstName(firstName)
				.setLastName(lastName)
				.setStudentId(studentId)
				.setDepartment(department)
				.setGender(gender)
				.setMaximumCredit(18)
				.build(); 
		CreateStudentRequest request = CreateStudentRequest.newBuilder().setToken(token).setStudent(student).build();
		ResultResponse response = crudStudentStub.createStudent(request);
		String result = response.getResult();
		if(result.equals("Success")) System.out.println("학생을 정상적으로 등록했습니다.");
		else if(result.equals("AlreadyExistSameStudentId")) System.out.println("이미 존재하는 학생ID입니다.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");

	}
	private int setStudentId(BufferedReader objectReader) throws IOException {
		while(true) {
			Integer studentId = Integer.parseInt(readIntegerInput("(8자리)학번: ", objectReader));
			if((int)(Math.log10(studentId)+1) == 8) return studentId;
			else System.out.println("8자리의 숫자를 입력하세요");
		}
	}
	private String setDepartment(BufferedReader objectReader) throws IOException {
		while(true) {
			System.out.println("밑에 보기 중에서 학과를 입력하세요.");
			System.out.println("(CS, EE, ME)");
			System.out.print("입력: ");
			String department = objectReader.readLine().trim();
			if(department.equals("CS")||department.equals("EE")||department.equals("ME")) {
				return department;
			} else System.out.println("잘못된 검색입니다. 다시 입력해주세요.");
		}
	}
	private String setGender(BufferedReader objectReader) throws IOException {
		while(true) {
			System.out.println("학생의 성별을 입력하세요.");
			System.out.println("(male, female)");
			System.out.print("입력: ");
			String gender = objectReader.readLine().trim();
			if(gender.equals("male")||gender.equals("female")) {
				return gender;
			} else System.out.println("잘못된 검색입니다. 다시 입력해주세요.");
		}
	}
	private void deleteStudentEntity(BufferedReader objectReader) throws IOException {
		List<Student> studentList = getStudentList("", "");		
		while(true) {
			if(studentList.size() == 0) break;
			else {
				System.out.println("삭제할 학생의 번호를 입력해주세요");
				System.out.print("입력: ");
				String sChoice = readIntegerInput("학생번호: ", objectReader);
				int choice = Integer.parseInt(sChoice);
				if (choice <= studentList.size()) {
					Student choiceStudent = studentList.get(choice - 1);
					DeleteStudentRequest request = DeleteStudentRequest.newBuilder().setToken(token).setStudent(choiceStudent).build();
					ResultResponse response = crudStudentStub.deleteStudent(request);
					String result = response.getResult();

					if(result.equals("Success")) System.out.println("선택한 학생을 삭제했습니다.");
					else if(result.equals("NullData")) System.out.println("학생 삭제에 실패했습니다. 다시 시도해주세요.");
					else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
					else System.out.println("서버 오류입니다. 다시 시도해주세요.");
					break;
				} else System.out.println("정확한 번호를 입력해주세요");
			}
		}
	}
	private void updateStudentEntity(BufferedReader objectReader) throws IOException {
		List<Student> studentList = getStudentList("", "");		
		while(true) {
			if(studentList.size() == 0) break;
			else {
				System.out.println("수정할 학생의 번호를 입력해주세요");
				System.out.print("입력: ");
				String sChoice = readIntegerInput("학생번호: ", objectReader);
				int choice = Integer.parseInt(sChoice);
				if (choice <= studentList.size()) {
					Student choiceStudent = studentList.get(choice - 1);
					
					System.out.println("새로운 학생정보를 입력하세요");
					System.out.print("성씨: ");
					String firstName = objectReader.readLine().trim();
					System.out.print("이름: ");
					String lastName = objectReader.readLine().trim();	
					String department = setDepartment(objectReader);
					String gender = setGender(objectReader);
					Student newStudent = Student.newBuilder()
							.setFirstName(firstName)
							.setLastName(lastName)
							.setStudentId(choiceStudent.getStudentId())
							.setDepartment(department)
							.setGender(gender)
							.setMaximumCredit(18)
							.build(); 
					UpdateStudentRequest request = UpdateStudentRequest.newBuilder().setToken(token)
							.setOriginStudent(choiceStudent).setNewStudent(newStudent).build();
					ResultResponse response = crudStudentStub.updateStudent(request);
					String result = response.getResult();

					if(result.equals("Success")) System.out.println("선택한 학생을 수정했습니다.");
					else if(result.equals("NullData")) System.out.println("학생 수정에 실패했습니다. 다시 시도해주세요.");
					else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
					else System.out.println("서버 오류입니다. 다시 시도해주세요.");
					break;
				} else System.out.println("정확한 번호를 입력해주세요");
			}
		}
	}
	private String inputError(BufferedReader objectReader) throws IOException {
		System.out.println("잘못된 입력입니다.");
		System.out.println("재검색 하시겠습니까?");
		System.out.println("1: 재검색");
		System.out.println("2: 검색종료");
		System.out.print("입력: ");
		String choiceMenu = objectReader.readLine().trim();
		return choiceMenu;
	}	
	public String readIntegerInput(String message, BufferedReader objectReader) throws IOException {
		while(true) {
			String input = objectReader.readLine().trim();
	        try {
	            Integer.parseInt(input);
	            return input; // 변환 성공
	        } catch (NumberFormatException e) {
	        	System.out.println("숫자를 입력하세요.");
	        	System.out.print(message);
	        }
		}
	}	
}

