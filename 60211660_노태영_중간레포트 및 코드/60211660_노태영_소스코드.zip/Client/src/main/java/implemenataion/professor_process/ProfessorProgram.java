package implemenataion.professor_process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import api.rpc.Course;
import api.rpc.CourseListRequest;
import api.rpc.CourseListResponse;
import api.rpc.CreateCourseRequest;
import api.rpc.CreateProfessorRequest;
import api.rpc.GetCourseServiceGrpc;
import api.rpc.GetStudentServiceGrpc;
import api.rpc.CrudCourseServiceGrpc;
import api.rpc.CrudProfessorServiceGrpc;
import api.rpc.DeleteCourseRequest;
import api.rpc.LoginRequest;
import api.rpc.LoginResponse;
import api.rpc.LoginServiceGrpc;
import api.rpc.Professor;
import api.rpc.ResultResponse;
import api.rpc.Student;
import api.rpc.StudentListRequest;
import api.rpc.StudentListResponse;
import api.rpc.Token;
import api.rpc.UpdateCourseRequest;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;


public class ProfessorProgram {
	private ManagedChannel channel;
	private Token token;
	private String name;
	private Integer professorId;
	private LoginServiceGrpc.LoginServiceBlockingStub  loginStub;
	private GetStudentServiceGrpc.GetStudentServiceBlockingStub getStudentStub;
	private GetCourseServiceGrpc.GetCourseServiceBlockingStub getCourseStub;
	private CrudCourseServiceGrpc.CrudCourseServiceBlockingStub CrudCourseStub;
	private CrudProfessorServiceGrpc.CrudProfessorServiceBlockingStub crudProfessorStub;
	
	
	public ProfessorProgram() {
		channel = ManagedChannelBuilder.forAddress("localhost", 9090).usePlaintext().build();
		loginStub = LoginServiceGrpc.newBlockingStub(channel);
		getCourseStub = GetCourseServiceGrpc.newBlockingStub(channel);
		getStudentStub = GetStudentServiceGrpc.newBlockingStub(channel);
		CrudCourseStub = CrudCourseServiceGrpc.newBlockingStub(channel);
		crudProfessorStub = CrudProfessorServiceGrpc.newBlockingStub(channel);
	}
	public static void main(String[] args) {		
		ProfessorProgram main = new ProfessorProgram();
		BufferedReader objectReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("본래 관리자 계정과 교수 계정을 생성하는 기능은 없으나");
		System.out.println("코드를 테스트하실 때 DDL만을 제출하여 테스트시 admin로그인과 교수 프로그램의 로그인이 수행되지 않기 때문에");
		System.out.println("교수, 관리자 회원가입 기능을 추가했습니다. 데이터 무결성이 지켜지지 않아 동일한 ID나 동일한 ProfessorId를 사용할 경우");
		System.out.println("무결성 오류가 발생허가나");
		System.out.println("무결성 오류를 알리는 것이 아닌 서버 오류를 알리는 점 양해부탁드립니다.");
		main.firstMenu(objectReader);
	}
	private void firstMenu(BufferedReader objectReader) {
		try {
			while (true) {
				System.out.println("*********************MENU*********************");
				System.out.println("1: 로그인");
				System.out.println("2: 교수등록");
				System.out.print("입력: ");
				String choice = objectReader.readLine().trim();
				switch(choice) {
				case "1":
					loginInput(objectReader);
					break;
				case "2":
					registerInput(objectReader);
					break;
				case "X":
					System.exit(0);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (StatusRuntimeException e) {
			System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
			ProfessorProgram main = new ProfessorProgram();
			main.firstMenu(objectReader);
		}
	}
	private void registerInput(BufferedReader objectReader) throws IOException {
		System.out.println("*************************교수등록*************************");
		System.out.print("성씨: ");
		String firstName = objectReader.readLine().trim();
		System.out.print("이름: ");
		String lastName = objectReader.readLine().trim();
		int professorId = setProfessorId(objectReader);
		String gender = setGender(objectReader);
		System.out.print("ID: ");
		String id = objectReader.readLine().trim();
		System.out.print("PASSWORD: ");
		String password = objectReader.readLine().trim();
		Professor professor = Professor.newBuilder()
				.setFirstName(firstName)
				.setLastName(lastName)
				.setProfessorId(professorId)
				.setGender(gender)
				.setId(id)
				.setPassword(password)
				.build();
		register(professor);
	}
	private void register(Professor professor) {
		CreateProfessorRequest request = CreateProfessorRequest.newBuilder().setProfessor(professor).build();
		ResultResponse response = crudProfessorStub.createProfessor(request);
		String result = response.getResult();
		if(result.equals("Success")) System.out.println("회원가입에 성공했습니다.");
		else if(result.equals("AlreadtExistSameProfessorId")) System.out.println("동일한 교수ID가 이미 존재합니다.");
		else if(result.equals("AlreadtExistSameId")) System.out.println("동일한 ID가 이미 존재합니다.");
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private String setGender(BufferedReader objectReader) throws IOException {
		while(true) {
			System.out.println("(male, female)");
			System.out.print("성별: ");
			String gender = objectReader.readLine().trim();
			if(gender.equals("male") || gender.equals("female")) return gender;
			else System.out.println("잘못된 입력입니다. 다시 입력해주세요");
		}
	}
	private int setProfessorId(BufferedReader objectReader) throws NumberFormatException, IOException {
		while(true) {
			Integer studentId = Integer.parseInt(readIntegerInput("(4자리)교수번호: ", objectReader));
			if((int)(Math.log10(studentId)+1) == 4) return studentId;
			else System.out.print("4자리의 숫자를 입력하세요");
		}
	}
	private void loginInput(BufferedReader objectReader){
		try {
			System.out.println("*********************LOGIN*********************");
			System.out.print("교수계정 ID: ");
			String id = objectReader.readLine().trim();
			System.out.print("교수계정 Password: ");
			String password = objectReader.readLine().trim();
			login(id, password, objectReader);	
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void login(String id, String password, BufferedReader objectReader) throws IOException {
		LoginRequest request = LoginRequest.newBuilder().setId(id).setPassword(password).setProcess("Professor").build();
		LoginResponse response = loginStub.login(request);
		String result = response.getResult();
		name = response.getName();
		professorId = response.getObjectId();
		if(result.equals("Success")) {token = response.getToken(); professorMenu(objectReader);}
		else if(result.equals("NullData")) loginFail(objectReader);
		else System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
	}
	private void loginFail(BufferedReader objectReader) throws IOException {
		System.out.println("해당 교수 계정이 존재하지 않습니다");
		System.out.println("재로그인 하시겠습니까?");
		System.out.println("1: 재로그인");
		System.out.println("2: Menu 돌아가기");
		System.out.println("X: 시스템 종료");
		System.out.print("입력: ");
		String choice = objectReader.readLine().trim();
		switch (choice){
		case"1" :
			loginInput(objectReader);
			break;
		case"2" :
			firstMenu(objectReader);
			break;
		case"X" :
			System.exit(0);
		}
	}
	private void professorMenu(BufferedReader objectReader) {
		System.out.println(name + "님 환영합니다.");
		try {
			while(true) {
				printMenu();
				String choiceMenu = objectReader.readLine().trim();
				switch(choiceMenu) {
				case "1" :
					getMyCourseList();
					break;
				case "2":
					getOtherCourseList(); 
					break;
				case "3":
					getAllPreviousCourse();
				case "4":
					getApplicationStudent(objectReader); 
					break;
				case "5":
					createCourse(objectReader); 
					break;
				case "6":
					deleteCourse(objectReader);
					break;
				case "7":
					updateCourse(objectReader);
					break;
				default:
					System.out.println("잘못된 입력입니다.");
				}
			}
		} catch (IOException e) {e.printStackTrace();}
		
	}
	private  void printMenu() {
		System.out.println("*********************MENU********************");
		System.out.println("1: 본인 개설강좌 출력");
		System.out.println("2: 타강좌 출력");
		System.out.println("3: 이전 개설강좌 출력");
		System.out.println("4: 신청학생 정보보기");
		System.out.println("5: 새로운 강좌 등록하기");
		System.out.println("6: 개설강좌 삭제하기");
		System.out.println("7: 개설강좌 수정하기");
		System.out.print("입력: ");
	}
	private List<Course> getMyCourseList() {
		CourseListRequest request = CourseListRequest.newBuilder()
				.setToken(token)
				.setProcess("Professor")
				.setCondition("MYCOURSE")
				.setConditionValue(professorId+"").build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = printAndReturnResult(response);
		if(list.size() == 0) System.out.println("개설한 강좌가 존재하지 않습니다.");
		else printCourseList(list);
		return list;
	}
	private List<Course> getOtherCourseList() {
		CourseListRequest request = CourseListRequest.newBuilder()
				.setToken(token)
				.setProcess("Professor")
				.setCondition("OTHERCOURSE")
				.setConditionValue(professorId+"")
				.build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = printAndReturnResult(response);
		if(list.size() == 0) System.out.println("타교수의 강좌가 존재하지 않습니다.");
		else printCourseList(list);
		return list;
	}
	private List<Course> getAllPreviousCourse() {
		CourseListRequest request = CourseListRequest.newBuilder()
				.setToken(token)
				.setProcess("Professor")
				.setCondition("PREVIOUSCOURSE")
				.build();
		CourseListResponse response = getCourseStub.getCourseList(request);
		List<Course> list = printAndReturnResult(response);
		if(list.size() == 0) System.out.println("타 교수의 강좌가 존재하지 않습니다.");
		else printCourseList(list);
		return list;
	}
	private List<Course> printAndReturnResult(CourseListResponse response) {
		List<Course> list = new ArrayList<Course>();
		String result = response.getResult();
		if(result.equals("Success")) list = response.getCourseList();
		else if(result.equals("NullData")) System.out.println("강좌가 없습니다");
		else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 잠시후 다시 로그인해주세요.");
		return list;
	}
	private void getApplicationStudent(BufferedReader objectReader) throws IOException {
		while (true) {
			List<Course> myCourseList = getMyCourseList();
			if(myCourseList.size() == 0) break;
			
			System.out.println("확인할 강좌의 번호를 입력해주세요");
			String sChoice = readIntegerInput("번호: ", objectReader);
			int choice = Integer.parseInt(sChoice);
			if (choice <= myCourseList.size()) {
				Course course = myCourseList.get(choice-1);
				StudentListRequest request = 
						StudentListRequest.newBuilder()
						.setToken(token)
						.setProcess("Professor")
						.setCondition("APPLICATION")
						.setConditionValue(((Integer)(course.getCourseId())).toString())
						.build();
				StudentListResponse response = getStudentStub.getStudentList(request);
				String result = response.getResult();
				if(result.equals("Success")) printStudentList(response.getStudentList());
				else if(result.equals("NullData")) System.out.println("강좌를 신청한 학생이 없습니다.");
				else if(result.equals("ServerError")) System.out.println("서버오류입니다. 잠시후 다시 이용해주세요.");
				else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 잠시후 다시 로그인해주세요.");
				break;
			}else System.out.println("잘못된 입력입니다.");
		}
	}
	private void createCourse(BufferedReader objectReader) throws IOException {
		System.out.println("강좌정보를 입력하세요");
		System.out.print("강좌명: ");
		String courseName = objectReader.readLine().trim();
		int courseId = setCourseId(objectReader);
		int [] requirementArray = setRequirement(objectReader);
		String credit = setCredit(objectReader);
		String maximumStudent = setMaximumStudent(objectReader);
		
		Course course = Course.newBuilder()
				.setName(courseName)
				.setCourseId(courseId)
				.setRequirement1(requirementArray[0])
				.setRequirement2(requirementArray[1])
				.setCredit(Integer.parseInt(credit))
				.setProfessorId(professorId)
				.setMaximumStudent(Integer.parseInt(maximumStudent))
				.build(); 
		CreateCourseRequest request = CreateCourseRequest.newBuilder().setToken(token).setCourse(course).build();
		ResultResponse response = CrudCourseStub.creatCourse(request);
		String result = response.getResult();
		
		if(result.equals("Success")) System.out.println("강좌가 정상적으로 생성됐습니다.");
		else if(result.equals("AlreadyExistSameCourseName")) System.out.println("같은 이름의 강좌가 이미 존재합니다.");
		else if(result.equals("AlreadyExistSameCourseId")) System.out.println("같은 강좌ID가 이미 존재합니다.");
		else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 잠시후 다시 로그인해주세요.");	
		else System.out.println("서버오류입니다. 잠시후 다시 로그인해주세요.");
	}
	private int setCourseId(BufferedReader objectReader) throws NumberFormatException, IOException {
		while(true) {
			Integer studentId = Integer.parseInt(readIntegerInput("(5자리)강좌번호: ", objectReader));
			if((int)(Math.log10(studentId)+1) == 5) return studentId;
			else System.out.print("5자리의 숫자를 입력하세요");
		}
	}
	private void deleteCourse(BufferedReader objectReader) throws IOException {
		while(true) {
			List<Course> myCourseList = getMyCourseList();
			if(myCourseList.size() == 0) break;
			else {
				System.out.println("삭제할 강좌의 번호를 입력해주세요");
				String sChoice = readIntegerInput("번호: ", objectReader);
				int choice = Integer.parseInt(sChoice);
				if (choice >  myCourseList.size()) System.out.println("정확한 번호를 입력해주세요");
				
				Course choiceCourse = myCourseList.get(choice - 1);
				DeleteCourseRequest request = DeleteCourseRequest.newBuilder().setToken(token).setCourse(choiceCourse).build();
				ResultResponse response = CrudCourseStub.deleteCourse(request);
				String result = response.getResult();

				if(result.equals("Success")) System.out.println("선택한 강좌를 삭제했습니다.");
				else if(result.equals("NullData")) System.out.println("강좌 삭제에 실패했습니다. 다시 시도해주세요.");
				else if(result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
				else System.out.println("서버 오류입니다. 다시 시도해주세요.");
				break;
			}
		}
	}

	private void updateCourse(BufferedReader objectReader) throws IOException {
		while(true) {
			List<Course> myCourseList = getMyCourseList();
			if(myCourseList.size() == 0) break;
			else {
				System.out.println("수정할 강좌의 번호를 입력해주세요");
				String sChoice = readIntegerInput("번호: ", objectReader);
				int choice = Integer.parseInt(sChoice);
				if (choice <= myCourseList.size()) {
					Course choiceCourse = myCourseList.get(choice - 1);
					Course newCourse = setUpdateCourse(objectReader, choiceCourse.getCourseId());
					UpdateCourseRequest request = UpdateCourseRequest.newBuilder().setToken(token).setOriginCourse(choiceCourse).setNewCourse(newCourse).build();
					ResultResponse response = CrudCourseStub.updateCourse(request);
					String result = response.getResult();

					if (result.equals("Success")) System.out.println("선택한 강좌를 수정했습니다.");
					else if (result.equals("AlreadyExistSameCourseName"))System.out.println("동일한 이름의 강좌가 이미 존재합니다.");
					else if (result.equals("NullData"))System.out.println("강좌 수정에 실패했습니다. 다시 시도해주세요.");
					else if (result.equals("TokenError")) System.out.println("토큰오류입니다. 다시 로그인해주세요.");
					else  System.out.println("서버 오류입니다. 다시 시도해주세요.");
					break;
				} else System.out.println("정확한 번호를 입력해주세요");
			}
		}
	}
	private Course setUpdateCourse(BufferedReader objectReader, int courseId) throws IOException {
		System.out.println("수정할 정보를 입력하세요");
		System.out.print("강좌명: ");
		String courseName = objectReader.readLine().trim();
		int[] requirementArray = setRequirement(objectReader);
		String credit = setCredit(objectReader);
		String maximumStudent = setMaximumStudent(objectReader);
		
		return Course.newBuilder().setName(courseName).setCourseId(courseId)
				.setRequirement1(requirementArray[0]).setRequirement2(requirementArray[1])
				.setCredit(Integer.parseInt(credit)).setProfessorId(professorId)
				.setMaximumStudent(Integer.parseInt(maximumStudent)).build();
	}
	private String setMaximumStudent(BufferedReader objectReader) throws IOException {
		while(true) {
			String maximumStudent = readIntegerInput("최대학생수: ", objectReader);
			if(Integer.parseInt(maximumStudent) <= 40 && Integer.parseInt(maximumStudent) >= 10) return maximumStudent;
			else System.out.println("10 ~40 사잇값을 입력해주세요.");
		}
	}
	private String setCredit(BufferedReader objectReader) throws IOException {
		while(true) {
			String credit = readIntegerInput("학점: ", objectReader);
			if(credit.equals("1") || credit.equals("2") || credit.equals("3")) return credit;
			else System.out.println("1~3을 입력해주세요.");
		}
	}
	private int[] setRequirement(BufferedReader objectReader) throws IOException {
		while(true) {
			System.out.println("선수과목 유무");
			System.out.println("1: 선수과목 O");
			System.out.println("2: 선수과목 X");
			System.out.print("입력: ");
			String choiceRequirement = objectReader.readLine().trim();
			switch (choiceRequirement) {
			case "1":
				return choiceRequirement(objectReader);
			case "2":
				int [] noneRequirement = {0, 0};
				return noneRequirement;
			}
		}
	}
	private int[] choiceRequirement(BufferedReader objectReader) throws IOException {
		List<Course> allCourseList = getAllPreviousCourse();
		String firstChoice;
		String secondChoice;
		while(true) {
			firstChoice = readIntegerInput("1번 선수과목 입력: ", objectReader);
			System.out.println("2번 선수과목이 없다면 0을 입력하시오.");
			secondChoice = readIntegerInput("2번 선수과목 입력: ", objectReader);
			if(firstChoice.equals(secondChoice)) System.out.println("서로 다른 강좌를 입력하세요.");
			else if(Integer.parseInt(firstChoice) > allCourseList.size() && Integer.parseInt(secondChoice) > allCourseList.size()) {
				System.out.println("정확한 숫자를 입력하세요");
			}
			else break;
		}
		Course firstRequirementCourse = allCourseList.get(Integer.parseInt(firstChoice)-1);
		if(secondChoice.equals("0")) {
			int [] requirementArray = {firstRequirementCourse.getCourseId(), 0};
			return requirementArray;
		}else {
			Course secondRequirementCourse = allCourseList.get(Integer.parseInt(secondChoice)-1);
			int [] requirementArray = {firstRequirementCourse.getCourseId(), secondRequirementCourse.getCourseId()};
			return requirementArray;
		}
	}
	private void printCourseList(List<Course> courseList) {
		String sCourseList = "";
		for (int i = 0; i < courseList.size(); i++) {
				Course course = courseList.get(i);
				sCourseList += i+1 + "번 강좌 -->> " +
						"강좌명: " + course.getName() + ", 강좌ID: " + course.getCourseId() + 
						", REQUIREMENT1: " + course.getRequirement1() + ", REQUIREMENT2: " + course.getRequirement2() + 
						", 학점: " + course.getCredit() + ", 교수이름: " + course.getProfessorName() + 
						", 교수ID: " + course.getProfessorId() + ", 최대수강자수: " + course.getMaximumStudent() + 
						", 수강자수: " + course.getNumberOfStudent() +  "\n";
			} System.out.println(sCourseList);
	}
	private void printStudentList(List<Student> studentList) {
		String sStudentListList = "";
		System.out.println("학생 리스트입니다.");
		for (int i = 0; i < studentList.size(); i++) {
			sStudentListList +=  i+1 + "번 학생 -->> " +
					"이름: " + studentList.get(i).getFirstName() + studentList.get(i).getLastName() +
					", 학번: " + studentList.get(i).getStudentId() + ", 학과: " + studentList.get(i).getDepartment() + 
					", 성별: " + studentList.get(i).getGender() + ", 학점: " + studentList.get(i).getScore() + 
					", 신청가능학점: " + studentList.get(i).getMaximumCredit() + "\n";
		} System.out.println(sStudentListList);
	}
	public String readIntegerInput(String message, BufferedReader objectReader) throws IOException {
		while(true) {
			System.out.print(message);
			String input = objectReader.readLine().trim();
	        try {
	            Integer.parseInt(input);
	            return input; // 변환 성공
	        } catch (NumberFormatException e) {
	        	System.out.println("숫자를 입력하세요.");
	        	System.out.print(message);
	        }
		}
	}
}



































